---
name: ergo-launch-review
description: "Use when I ask for a launch-readiness review, overdue action check, or owner-and-dependency review of the fictional ERGO pilot register in Excel."
---

# Review the pilot register

Work only with the open workbook's PilotRegister table. Preserve the source table, its existing values and the fictional-data classification. Do not mark actions complete or assign real people.

1. Validate unique RecordID values, recognized ItemType and Status values, nonempty owner roles and parseable ISO dates. Every nonempty DependencyID must resolve to a source RecordID. Report errors and their row IDs explicitly before classifying; never silently drop bad rows.
2. Use the single AsOfDate in the source as the reporting date, not TODAY(). If dates disagree, stop and ask which snapshot to use. ISO text dates must be converted to real Excel dates before comparison.
3. Create or update one worksheet named "Launch review". Set B2 to the reporting date and label A2 "As of". Show formula-driven metrics labeled "Total items", "Blocked items" and "Overdue actions".
4. An overdue action has ItemType Action, Status other than Closed, and DueDate strictly before B2. A due date equal to B2 is not overdue. Risks are never counted as overdue actions. Count Blocked items across both types; do not equate blocked with overdue.
5. Add a filterable review table containing all source items: RecordID, Title, ItemType, OwnerRole, DueDate, Status, DependencyID, OverdueAction and DependencyStatus. Reference source data and use formulas for classifications, dependency lookup and metrics. A blank dependency means "None". A nonexistent dependency is an error, not "None". Distinguish missing evidence from a proven failure.
6. Highlight overdue actions and blocked items without hiding or altering the source. Keep formulas inspectable, dates unambiguous, columns readable and the fictional-data label visible. Use Arial and restrained red headers.
7. Add a short plain-English note naming the overdue action IDs and owners, their downstream consequences, and the distinction between blocked and overdue. State that this is a snapshot review, not a launch authorization. Flag that this narrative note must be refreshed after source edits even though formulas recalculate.

Finish in chat with the reporting date, the three counts and the source IDs that require attention. Never invent a missing owner, assume approval, or use the real calendar date to age a fictional snapshot.
