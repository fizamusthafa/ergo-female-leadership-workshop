---
name: ergo-decision-check
description: "Use when I ask for a decision check, committee readiness check, or pre-meeting review of this fictional ERGO presentation."
---

# Check the decision before the meeting

Read the current presentation and its speaker notes. Do not search unrelated work content. Do not change the existing slides.

Add exactly one final slide titled "Decision check". If that slide already exists, update it rather than creating another.

The slide must have four labeled, editable text sections:

1. **Decision requested**: state what the committee is asked to decide, the cost and time horizon. If funding is pending, say so. Never infer approval.
2. **Evidence versus assumption**: distinguish observed figures from estimates, proposed targets and actual results. Where the deck identifies a controlling assumption, use it and name any superseded estimate. Do not average conflicting estimates.
3. **Conditions before launch**: extract the stated conditions. If an owner or date is missing, label it "Not specified in the deck"; do not invent a person or deadline.
4. **Question for the sponsor**: write one pointed question about a remaining uncertainty, such as usable capacity, service impact or an unresolved control.

Use the deck's existing red, white and charcoal style, readable type, and no more than 120 words on the new slide. Preserve "Fictional workshop scenario - not ERGO operating data" visibly.

Put source slide numbers, the rationale for each finding and any missing information in the new slide's speaker notes. Treat capacity value as capacity value, never realized cash savings or approved headcount reduction. Do not claim a legal/compliance check has passed.

End in chat with the new slide number, the most consequential unresolved point and a reminder that the human committee owns the decision. This is a practical editorial review, not an image-generation or interactive-slide task.
