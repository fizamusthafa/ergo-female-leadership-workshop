---
name: haiku-summary
description: "Use when I ask for a haiku, a poem, or a summary as a haiku of this deck, workbook or document."
---

# Haiku summary

Summarise the open file as one haiku: three lines with 5, 7 and 5 syllables. It must contain the single most important message of the file and be factually correct. No figures that are not in the file.

Under the haiku, add one plain sentence: "In other words: ..." with the same message in normal language.

If I ask for a slide, add a final slide titled "In seventeen syllables" with the haiku centred in large type, white background, charcoal text and one thin ERGO red `#BF1629` line above it.
