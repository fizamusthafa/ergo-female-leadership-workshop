# ERGO investor style: design reference

Layout measured from public investor and media decks (2026); brand from the ERGO design guideline
(Logo Red #BF1528 verified; Dark Red #7A0E1C is a stand-in until the exact Brand Coach value is known).

## Grid (inches, 13.333 x 7.5)
- Margins 0.5. Title (0.5, 0.36, w 10.4), 24 pt regular red, 1-2 lines. Kicker (optional) 10 pt bold grey above.
- Logo top-right, height 0.32 (width 1.04). Cover/closer: white logo bottom-right, height 0.5.
- Content band y 1.5 - 6.45. Side panel x 8.6 to the right edge, y 1.45 - 6.5. Takeaway band y 5.75, h 0.7.
- Footer y 7.08: source left (9 pt grey), "Event - Title" + bold page number right.

## Type scale (pt)
Cover title 40 bold white | slide title 24 red | section head 20 bold red | subhead 15 red | body 14 ink |
bullets 13-14 | chart title 14 bold + unit regular | axis/legend 12 | KPI value 28 bold white | footer 9.
`text(..., fit=True)` shrinks text to fit its box (down to min_size); still keep words minimal.

## Components
| Component | Helper | Notes |
|---|---|---|
| Cover / closer | `cover` | user photo + dark shade, or shape-built red field; white logo bottom-right |
| Divider | `divider` | red block left, big white title, grey numeral right; use for "Appendix" |
| Agenda | `agenda` | active red tile (2-digit numeral, optional detail bullets), grey tiles bottom-aligned |
| Side panel | `side_panel` | "Trends" / "Observations": bold head, red subhead, 3-5 red square bullets |
| Takeaway band | `takeaway` | one bold white sentence, full width |
| KPI tiles | `kpi_tiles` | label, note under it, big value bottom-left; `cols` wraps into a grid |
| Pillars | `pillars` | grey columns, icon or numbered disc, red heading, text or bullets |
| Timeline | `timeline` | red rail with arrow, discs, when above, what below; `now` filled |
| Bars + CAGR | `bar_chart` | bracket + red pill only when cagr is given; threshold dotted dark red |
| Horizontal bars | `hbars` | ranking; highlight one in red, others light red |
| Donut + legend | `donut`, `legend` | smooth wedge fans (2.5 deg), white separators, centre label |
| KPI ring | `kpi_ring` | native ellipse + masked wedges (smooth); hero ring dark red and larger |

## Rules that keep it looking right
- One idea per slide; fill the content band (no empty halves): pair a chart with a side panel, or tiles with pillars.
- Rows of like items get the same line count. Values are printed on every bar.
- Prior period light tint #EBB9BE vs current period red. Dark red only for one highlight per slide.
- Z-order is creation order: panels first, then text, then lines and markers.
- A full-bleed shape may touch the left/right edge; nothing else leaves the slide.
