#!/usr/bin/env python3
"""Render a deck for visual QA and run quick geometry checks.

usage: python render_check.py deck.pptx [out_dir]
-> out_dir/slide-NN.png (one per slide) + out_dir/contact.png (all slides on one sheet)
-> prints shapes that sit outside the slide, text boxes below the footer line, and overlapping
   text boxes (likely collisions). Look at every picture before delivering.
"""
import glob, os, subprocess, sys
from pptx import Presentation
from pptx.util import Emu

def checks(path):
    prs = Presentation(path); W, H = prs.slide_width, prs.slide_height; out = []
    for i, s in enumerate(prs.slides, 1):
        boxes = []
        for sh in s.shapes:
            if sh.left is None: continue
            if sh.left < -Emu(10000) or sh.top < -Emu(10000) or sh.left + sh.width > W + 10000 or sh.top + sh.height > H + 10000:
                if not (sh.width >= W * 0.3):  # full-bleed panels and bands are fine
                    out.append(f"slide {i}: '{sh.name}' extends past the slide edge")
            if sh.has_text_frame and sh.text_frame.text.strip():
                boxes.append((sh.left, sh.top, sh.left + sh.width, sh.top + sh.height, sh.text_frame.text.strip()[:30]))
        for a in range(len(boxes)):
            for b in range(a + 1, len(boxes)):
                A, B = boxes[a], boxes[b]
                ix = min(A[2], B[2]) - max(A[0], B[0]); iy = min(A[3], B[3]) - max(A[1], B[1])
                if ix > Emu(91440) and iy > Emu(45720):
                    out.append(f"slide {i}: text boxes overlap: '{A[4]}' / '{B[4]}'")
    return out

if __name__ == "__main__":
    deck = os.path.abspath(sys.argv[1]); od = os.path.abspath(sys.argv[2] if len(sys.argv) > 2 else "renders")
    os.makedirs(od, exist_ok=True)
    for msg in checks(deck): print("CHECK", msg)
    subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", od, deck], capture_output=True, timeout=180)
    pdf = os.path.join(od, os.path.splitext(os.path.basename(deck))[0] + ".pdf")
    for f in glob.glob(os.path.join(od, "slide-*.png")): os.remove(f)
    subprocess.run(["pdftoppm", "-r", "60", "-png", pdf, os.path.join(od, "slide")], check=True)
    from PIL import Image
    fs = sorted(glob.glob(os.path.join(od, "slide-*.png"))); ims = [Image.open(f) for f in fs]
    w, h = ims[0].size; cols = 3; rows = (len(ims) + cols - 1) // cols
    sheet = Image.new("RGB", (w * cols + 10 * (cols - 1), h * rows + 10 * (rows - 1)), "#888888")
    for k, im in enumerate(ims): sheet.paste(im, ((k % cols) * (w + 10), (k // cols) * (h + 10)))
    sheet.save(os.path.join(od, "contact.png")); print(f"{len(fs)} slides rendered -> {od}/contact.png")
