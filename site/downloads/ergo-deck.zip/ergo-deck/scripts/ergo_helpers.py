"""ERGO investor-style helpers for python-pptx (16:9, 13.333 x 7.5 in).

Layout = investor-deck style, brand = ERGO (Logo Red #BF1528, Arial, ERGO wordmark top-right).

Usage:
    import sys; sys.path.insert(0, "<skill_dir>/scripts")
    from ergo_helpers import *
    prs = new_deck()
    cover(prs, "Title", "Event | Format", "17 November 2026", "Name | Name")
    s = content_slide(prs, "Message title", event="Event - Title", page=2, source="Source: ...")
    bar_chart(s, ["2024", "2025", "2026"], [4.2, 5.1, 6.4], 0.5, 1.9, 7.2, 4.0, title="Sessions", unit="(k)")
    side_panel(s, "Observations", "Subhead", ["Point one", "Point two"])
    prs.save("deck.pptx")

Everything is a native shape (no images, no native charts) so it stays crisp and editable.
"""
import json
import math
import os
import re

from lxml import etree
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

# ---- palette (ERGO; see references/design-reference.md) -------------------
RED = "BF1528"        # ERGO Logo Red (verified): titles, bands, tiles, primary bars
DARK = "7A0E1C"       # Dark Red stand-in: thresholds, annotations, hero ring, eye-catchers
WARM = "615E5C"       # Warm Grey (sparingly): secondary series
INK = "262626"        # body text
MUTED = "4D4D4D"      # footer, sources
PANEL = "EFEDED"      # side panels, pillars, inactive agenda tiles
GRID = "D9D4D4"       # gridlines, ring track
HAIR = "C9C3C3"       # separators
TINTS = ["CF4F5E", "DF8A93", "EBB9BE", "F5DCDF"]   # red 75 / 50 / 30 / blush
SERIES = [RED, DARK, "DF8A93", WARM, "EBB9BE", "8C8C8C", "B3B3B3", "D9D9D9"]
ON_RED = "F5DCDF"     # secondary text on red
WHITE = "FFFFFF"
FONT = "Arial"

SLIDE_W, SLIDE_H = 13.333, 7.5
MARGIN = 0.5
CONTENT_TOP, CONTENT_BOTTOM = 1.5, 6.45   # keep content inside this band
_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")
_CACHE = {}


def rgb(hex_):
    return RGBColor.from_string(hex_.lstrip("#"))


# ---- vector assets (logo + icons from JSON path data) ----------------------
def _parse_path(d):
    """SVG path data (absolute M L H V C Z) -> [(op, [x, y, ...])] with H/V expanded to L."""
    out, cur, start = [], (0.0, 0.0), (0.0, 0.0)
    toks = re.findall(r"[MLHVCZmlhvcz]|-?\d*\.?\d+(?:[eE]-?\d+)?", d)
    i, cmd = 0, None
    def num():
        nonlocal i
        v = float(toks[i]); i += 1; return v
    while i < len(toks):
        if toks[i].isalpha():
            cmd = toks[i]; i += 1
            if cmd in "Zz":
                out.append(("Z", [])); cur = start; continue
        if cmd == "M":
            cur = (num(), num()); start = cur; out.append(("M", list(cur))); cmd = "L"
        elif cmd == "L":
            cur = (num(), num()); out.append(("L", list(cur)))
        elif cmd == "H":
            cur = (num(), cur[1]); out.append(("L", list(cur)))
        elif cmd == "V":
            cur = (cur[0], num()); out.append(("L", list(cur)))
        elif cmd == "C":
            pts = [num() for _ in range(6)]; cur = (pts[4], pts[5]); out.append(("C", pts))
        else:
            raise ValueError(f"unsupported path command {cmd!r} - store absolute M L H V C Z only")
    return out


def _asset(name):
    if name not in _CACHE:
        with open(os.path.join(_ASSETS, name), encoding="utf-8") as fh:
            _CACHE[name] = json.load(fh)
    return _CACHE[name]


ICON_NAMES = sorted(_asset("icons.json")["icons"]) if os.path.exists(os.path.join(_ASSETS, "icons.json")) else []


def _vector(slide, paths, viewbox, x, y, w, h, color, name):
    """One native freeform shape from SVG path data (exact curves, never blurry)."""
    vx, vy, vw, vh = [float(v) for v in viewbox.split()]
    shp = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    shp.name = name
    shp.line.fill.background()
    shp.fill.solid(); shp.fill.fore_color.rgb = rgb(color)
    _flat(shp)
    S = 1000
    spPr = shp._element.spPr
    prst = spPr.find(qn("a:prstGeom"))
    geom = etree.Element(qn("a:custGeom"))
    for tag in ("a:avLst", "a:gdLst", "a:ahLst", "a:cxnLst"):
        etree.SubElement(geom, qn(tag))
    r = etree.SubElement(geom, qn("a:rect")); r.set("l", "0"); r.set("t", "0"); r.set("r", "r"); r.set("b", "b")
    pl = etree.SubElement(geom, qn("a:pathLst"))
    path = etree.SubElement(pl, qn("a:path")); path.set("w", str(round(vw * S))); path.set("h", str(round(vh * S)))
    for d in paths:
        for op, n in _parse_path(d):
            if op == "Z":
                etree.SubElement(path, qn("a:close")); continue
            el = etree.SubElement(path, qn({"M": "a:moveTo", "L": "a:lnTo", "C": "a:cubicBezTo"}[op]))
            for j in range(0, len(n), 2):
                p = etree.SubElement(el, qn("a:pt"))
                p.set("x", str(round((n[j] - vx) * S))); p.set("y", str(round((n[j + 1] - vy) * S)))
    prst.addprevious(geom); spPr.remove(prst)
    return shp


def logo(slide, white=False, x=None, y=0.4, h=0.32):
    """ERGO wordmark as one native vector shape. Red on white/grey, white on red.
    Default position: top-right. Aspect ratio is fixed by the path data."""
    L = _asset("logo.json")
    vb = [float(v) for v in L["viewBox"].split()]
    w = h * vb[2] / vb[3]
    left = x if x is not None else SLIDE_W - MARGIN - w
    return _vector(slide, L["paths"], L["viewBox"], left, y, w, h, WHITE if white else RED, "ERGO logo")


def icon(slide, name, x, y, size=0.55, color=RED):
    """ERGO-style icon (see ICON_NAMES). Use only when the icon really matches the meaning;
    otherwise use number_disc()."""
    ic = _asset("icons.json")["icons"][name]
    return _vector(slide, ic["paths"], ic["viewBox"], x, y, size, size, color, f"icon {name}")


# ---- primitives ------------------------------------------------------------
def new_deck():
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(SLIDE_W), Inches(SLIDE_H)
    return prs


def blank(prs):
    return prs.slides.add_slide(prs.slide_layouts[6])


def _flat(shp):
    shp.shadow.inherit = False
    st = shp._element.find(qn("p:style"))
    if st is not None:
        shp._element.remove(st)


def rect(slide, x, y, w, h, fill, shape=MSO_SHAPE.RECTANGLE, line=None, line_w=None, rot=0, dash=None):
    shp = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    if fill is None:
        shp.fill.background()
    else:
        shp.fill.solid(); shp.fill.fore_color.rgb = rgb(fill)
    if line:
        shp.line.color.rgb = rgb(line); shp.line.width = Pt(line_w or 1)
        if dash:
            from pptx.enum.dml import MSO_LINE_DASH_STYLE
            shp.line.dash_style = getattr(MSO_LINE_DASH_STYLE, dash)
    else:
        shp.line.fill.background()
    _flat(shp)
    shp.rotation = rot
    return shp


def _fit(lines, size, w, h, min_size):
    """Shrink the font until the estimated wrapped height fits (Arial ~0.5 em average width)."""
    s = size
    while s > min_size:
        cpl = max(1, int(w * 72 / (s * 0.5)))
        n = sum(max(1, math.ceil(len(l) / cpl)) for l in lines)
        if n * s * 1.25 / 72 + (len(lines) - 1) * 6 / 72 <= h:
            break
        s -= 1
    return s


def text(slide, x, y, w, h, txt, size=14, color=INK, bold=False, align=PP_ALIGN.LEFT,
         anchor=MSO_ANCHOR.TOP, bullets=False, fit=True, min_size=10):
    """Text box. `txt` = string or list of lines (one paragraph each). fit=True shrinks the font
    (down to min_size) when the text would overflow the box."""
    lines = txt if isinstance(txt, list) else [txt]
    if fit:
        size = _fit([("    " if bullets else "") + l for l in lines], size, w, h, min_size)
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    for m in ("margin_left", "margin_right", "margin_top", "margin_bottom"):
        setattr(tf, m, 0)
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        if bullets:
            _bullet(p, size, RED if color not in (WHITE,) else WHITE)
        r = p.add_run(); r.text = line
        f = r.font
        f.name, f.size, f.bold, f.color.rgb = FONT, Pt(size), bold, rgb(color)
    return tb


def _bullet(p, size, colour=RED):
    """Real square bullet (red) with hanging indent, so wrapped lines align."""
    pPr = p._p.get_or_add_pPr()
    pPr.set("marL", str(int(size * 1.15 * 12700))); pPr.set("indent", str(-int(size * 1.15 * 12700)))
    for tag, attrs in (("a:spcAft", None), ("a:buClr", None), ("a:buFont", {"typeface": "Wingdings"}),
                       ("a:buChar", {"char": "\u00a7"})):
        el = etree.SubElement(pPr, qn(tag))
        if tag == "a:spcAft":
            etree.SubElement(el, qn("a:spcPts")).set("val", "600")
        elif tag == "a:buClr":
            etree.SubElement(el, qn("a:srgbClr")).set("val", colour)
        else:
            for k, v in attrs.items():
                el.set(k, v)


def _alpha(shape, pct):
    """Fill opacity in % (100 = solid)."""
    clr = shape.fill._xPr.find(qn("a:solidFill"))[0]
    clr.append(clr.makeelement(qn("a:alpha"), {"val": str(int(pct * 1000))}))


# ---- frame -----------------------------------------------------------------
def frame(slide, title, event="", page=None, source=None, kicker=None):
    """Red message title top-left (24 pt regular), ERGO logo top-right, footer 'Event - Title' + bold
    page number bottom-right, source bottom-left. kicker = small grey label above the title
    (e.g. 'Appendix')."""
    ty = 0.36
    if kicker:
        text(slide, MARGIN, 0.2, 6, 0.22, kicker.upper(), size=10, color=MUTED, bold=True, fit=False)
        ty = 0.44
    text(slide, MARGIN, ty, 10.4, 0.85, title, size=24, color=RED, min_size=18)
    logo(slide)
    if event or page is not None:
        tb = text(slide, SLIDE_W - 5.5, SLIDE_H - 0.42, 5.0, 0.22, event, size=9, color=MUTED,
                  align=PP_ALIGN.RIGHT, fit=False)
        if page is not None:
            r = tb.text_frame.paragraphs[0].add_run()
            r.text = "     " + str(page)
            r.font.name, r.font.size, r.font.bold, r.font.color.rgb = FONT, Pt(9), True, rgb(INK)
    if source:
        text(slide, MARGIN, SLIDE_H - 0.42, 7.4, 0.3, source, size=9, color=MUTED, min_size=7)


def content_slide(prs, title, event="", page=None, source=None, kicker=None):
    s = blank(prs)
    frame(s, title, event, page, source, kicker)
    return s


# ---- cover, closer, divider -------------------------------------------------
def _flip_h(shp):
    shp._element.spPr.find(qn("a:xfrm")).set("flipH", "1")
    return shp


def _red_field(s):
    """Shape-built ERGO red background: Logo Red with two calm dark-red planes, darker lower-left."""
    rect(s, 0, 0, SLIDE_W, SLIDE_H, RED)
    _alpha(_flip_h(rect(s, 5.8, 0, 7.533, SLIDE_H, DARK, MSO_SHAPE.RIGHT_TRIANGLE)), 30)
    _alpha(_flip_h(rect(s, 9.4, 0, 3.933, SLIDE_H, DARK, MSO_SHAPE.RIGHT_TRIANGLE)), 30)
    _alpha(rect(s, 0, SLIDE_H - 2.9, 8.0, 2.9, DARK), 25)


def cover(prs, title, subtitle="", date="", speakers="", photo=None, closer=False):
    """Cover / closer. With a user photo: full-bleed photo + dark lower-left shade. Without: shape-built
    red field. Bold white title, subtitle, date, speakers, white ERGO logo bottom-right."""
    s = blank(prs)
    if photo and os.path.exists(photo):
        s.shapes.add_picture(photo, 0, 0, Inches(SLIDE_W), Inches(SLIDE_H))
        _alpha(rect(s, 0, SLIDE_H * 0.42, SLIDE_W * 0.62, SLIDE_H * 0.58, "1E1E1E"), 50)
    else:
        _red_field(s)
    text(s, 0.7, 2.6, 8.6, 2.2, "Thank you." if closer else title, size=40, color=WHITE, bold=True,
         anchor=MSO_ANCHOR.BOTTOM, min_size=28)
    lines = [l for l in ((subtitle,) if closer else (subtitle, date, speakers)) if l]
    if lines:
        text(s, 0.7, 5.0, 8.6, 1.3, lines, size=16, color=WHITE)
    logo(s, white=True, x=SLIDE_W - 0.6 - 0.5 * 81 / 25, y=SLIDE_H - 0.95, h=0.5)
    return s


def divider(prs, title, subtitle="", label="", number=None):
    """Section / appendix divider: red left block with big white title, light right side."""
    s = blank(prs)
    rect(s, 0, 0, 7.6, SLIDE_H, RED)
    _alpha(rect(s, 0, SLIDE_H - 2.2, 7.6, 2.2, DARK), 30)
    if label:
        text(s, 0.7, 1.2, 6.2, 0.35, label.upper(), size=12, color=ON_RED, bold=True, fit=False)
    text(s, 0.7, 1.7, 6.2, 2.4, title, size=36, color=WHITE, bold=True, min_size=26)
    if subtitle:
        text(s, 0.7, 4.2, 6.2, 1.0, subtitle, size=16, color=ON_RED)
    if number is not None:
        text(s, 8.2, 1.6, 4.6, 4.6, f"{number:02d}" if isinstance(number, int) else str(number), size=150,
             color=PANEL, bold=True, align=PP_ALIGN.RIGHT, anchor=MSO_ANCHOR.BOTTOM, fit=False)
    logo(s, x=SLIDE_W - 0.6 - 0.4 * 81 / 25, y=SLIDE_H - 0.85, h=0.4)
    return s


# ---- components --------------------------------------------------------------
def agenda(prs, sections, active, event="", page=None, detail=None):
    """sections = [(title, subtitle)], active = 0-based index. Active = big red tile with a large
    numeral (and optional `detail` bullets), others = shorter grey tiles; all bottom-aligned."""
    s = content_slide(prs, "Agenda", event, page)
    n = len(sections)
    gap, top, bottom = 0.2, 1.55, 6.45
    big_w = 4.6 if n > 1 else SLIDE_W - 2 * MARGIN
    small_w = (SLIDE_W - 2 * MARGIN - big_w - gap * (n - 1)) / max(n - 1, 1)
    x = MARGIN
    for i, (t, sub) in enumerate(sections):
        on = i == active
        w = big_w if on else small_w
        y = top if on else top + 1.1
        h = bottom - y
        rect(s, x, y, w, h, RED if on else PANEL)
        col = WHITE if on else MUTED
        text(s, x + 0.3, y + 0.3, w - 0.6, 0.85, t, size=22 if on else 15, color=col, bold=True)
        text(s, x + 0.3, y + 1.1, w - 0.6, 0.8, sub, size=15 if on else 12, color=ON_RED if on else MUTED)
        if on and detail:
            text(s, x + 0.3, y + 1.95, w - 1.9, 2.4, detail, size=13, color=WHITE, bullets=True)
        text(s, x + 0.1, y + h - 1.75, w - 0.35, 1.6, f"{i + 1:02d}", size=72 if on else 44,
             color=WHITE if on else "B3B3B3", align=PP_ALIGN.RIGHT, anchor=MSO_ANCHOR.BOTTOM, fit=False)
        x += w + gap
    return s


def side_panel(slide, head, subhead, points, x=8.6):
    """Grey 'Trends / Observations' panel bleeding off the right edge (ends at y 6.5)."""
    rect(slide, x, 1.45, SLIDE_W - x, 5.05, PANEL)
    w = SLIDE_W - x - 0.75
    text(slide, x + 0.4, 1.75, w, 0.42, head, size=20, color=RED, bold=True)
    y = 2.25
    if subhead:
        text(slide, x + 0.4, y, w, 0.55, subhead, size=15, color=RED); y += 0.7
    text(slide, x + 0.4, y, w, 6.2 - y, points, size=14, bullets=True, min_size=11)


def takeaway(slide, sentence, y=5.75, h=0.7):
    """Full-width red band with one bold white sentence. Keep content above y."""
    rect(slide, 0, y, SLIDE_W, h, RED)
    text(slide, 0.6, y, SLIDE_W - 1.2, h, sentence, size=18, color=WHITE, bold=True,
         align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, min_size=14)


def kpi_tiles(slide, items, y=1.6, h=1.35, x=MARGIN, w=None, cols=None):
    """items = [(label, value, explanation)] -> red tiles: bold label, small note under it, big value
    bottom-left. cols < len(items) wraps into rows (row height h, gap 0.2)."""
    w = w or SLIDE_W - 2 * MARGIN
    cols = cols or len(items)
    gap = 0.2
    tw = (w - gap * (cols - 1)) / cols
    for i, (lab, val, exp) in enumerate(items):
        tx = x + (i % cols) * (tw + gap)
        ty = y + (i // cols) * (h + gap)
        rect(slide, tx, ty, tw, h, RED)
        text(slide, tx + 0.2, ty + 0.15, tw - 0.4, 0.3, lab, size=13, color=WHITE, bold=True)
        if exp:
            text(slide, tx + 0.2, ty + 0.45, tw - 0.4, 0.26, exp, size=11, color=ON_RED, min_size=9)
        text(slide, tx + 0.2, ty + h - 0.68, tw - 0.4, 0.56, str(val), size=28, color=WHITE, bold=True,
             anchor=MSO_ANCHOR.BOTTOM, min_size=18)


def number_disc(slide, n, cx, cy, d=0.5, fill=RED):
    rect(slide, cx - d / 2, cy - d / 2, d, d, fill, MSO_SHAPE.OVAL)
    text(slide, cx - d / 2, cy - d / 2, d, d, str(n), size=16, color=WHITE, bold=True,
         align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, fit=False)


def pillars(slide, items, y=1.6, h=4.0, x=MARGIN, w=None):
    """items = [(icon_or_None, heading, body)] -> grey columns. body = string or list (bullets).
    Icon must be a name from ICON_NAMES that matches the meaning; None gives a numbered disc."""
    w = w or SLIDE_W - 2 * MARGIN
    gap = 0.2
    n = len(items)
    cw = (w - gap * (n - 1)) / n
    for i, (ic, head, body) in enumerate(items):
        cx = x + i * (cw + gap)
        rect(slide, cx, y, cw, h, PANEL)
        if ic:
            icon(slide, ic, cx + 0.3, y + 0.3, 0.6)
        else:
            number_disc(slide, i + 1, cx + 0.55, y + 0.55)
        text(slide, cx + 0.3, y + 1.15, cw - 0.6, 0.5, head, size=17, color=RED, bold=True, min_size=13)
        text(slide, cx + 0.3, y + 1.75, cw - 0.6, h - 2.0, body, size=14,
             bullets=isinstance(body, list), min_size=11)


def timeline(slide, items, y=2.2, now=None, x=MARGIN, w=None):
    """items = [(when, what)] -> rail with discs; 'when' above in bold red, 'what' below.
    `now` = index drawn as a filled disc. Occupies about y .. y+2.6."""
    w = w or SLIDE_W - 2 * MARGIN
    n = len(items)
    slot = w / n
    ry = y + 0.75
    rect(slide, x, ry - 0.015, w, 0.03, RED)
    tri = rect(slide, x + w - 0.02, ry - 0.09, 0.14, 0.18, RED, MSO_SHAPE.ISOSCELES_TRIANGLE, rot=90)
    for i, (when, what) in enumerate(items):
        cx = x + slot * i + slot / 2
        text(slide, cx - slot / 2 + 0.1, y, slot - 0.2, 0.5, when, size=16, color=RED, bold=True,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.BOTTOM, min_size=12)
        d = 0.26
        rect(slide, cx - d / 2, ry - d / 2, d, d, RED if i == now else WHITE, MSO_SHAPE.OVAL,
             line=RED, line_w=2.25)
        text(slide, cx - slot / 2 + 0.1, ry + 0.35, slot - 0.2, 1.5, what, size=13,
             align=PP_ALIGN.CENTER, min_size=10)
    return tri


# ---- charts (shape-built) ---------------------------------------------------
def bar_chart(slide, labels, values, x, y, w, h, title="", unit="", cagr=None, color=RED,
              colors=None, decimals=0, threshold=None, accent_ends=False):
    """Vertical bars with light gridlines and values on top. cagr='5.8% CAGR' adds an elbow bracket
    first->last bar with a red pill (space for it is reserved only when asked). threshold=(value,
    'label') draws a dotted dark-red line; accent_ends prints first/last value in dark red."""
    if title:
        tb = text(slide, x, y, w, 0.3, title, size=14, bold=True, fit=False)
        if unit:
            r = tb.text_frame.paragraphs[0].add_run(); r.text = " " + unit
            r.font.name, r.font.size, r.font.color.rgb = FONT, Pt(14), rgb(INK)
        y += 0.45; h -= 0.45
    h -= 0.35  # category labels
    top_room = 0.75 if cagr else 0.35
    vmax = max(list(values) + ([threshold[0]] if threshold else [])) or 1
    scale = (h - top_room) / vmax
    n = len(values)
    slot = w / n
    bw = min(slot * 0.56, 1.3)
    base = y + h
    for g in range(1, 5):
        rect(slide, x, base - (h - top_room) * g / 4, w, 0.01, GRID)
    rect(slide, x, base, w, 0.015, "8C8C8C")
    tops = []
    for i, (lab, v) in enumerate(zip(labels, values)):
        bh = v * scale
        bx = x + i * slot + (slot - bw) / 2
        rect(slide, bx, base - bh, bw, bh, (colors or [color] * n)[i])
        acc = accent_ends and i in (0, n - 1)
        text(slide, bx - 0.3, base - bh - 0.32, bw + 0.6, 0.28, f"{v:,.{decimals}f}", size=13,
             color=DARK if acc else INK, bold=True, align=PP_ALIGN.CENTER, fit=False)
        text(slide, x + i * slot, base + 0.08, slot, 0.28, str(lab), size=12, color=MUTED,
             align=PP_ALIGN.CENTER, fit=False)
        tops.append((bx + bw / 2, base - bh))
    if threshold:
        ty = base - threshold[0] * scale
        rect(slide, x, ty, w, 0, None, line=DARK, line_w=1.5, dash="ROUND_DOT")
        # label where the end bar stays below the line; else as a legend line under the title
        if values[-1] < threshold[0]:
            text(slide, x + w - 2.6, ty - 0.3, 2.6, 0.24, threshold[1], size=11, color=DARK, bold=True,
                 align=PP_ALIGN.RIGHT, fit=False)
        elif values[0] < threshold[0]:
            text(slide, x, ty - 0.3, 2.6, 0.24, threshold[1], size=11, color=DARK, bold=True, fit=False)
        else:
            text(slide, x + w - 3.2, y - 0.4, 3.2, 0.24, "\u2219\u2219\u2219  " + threshold[1], size=11,
                 color=DARK, bold=True, align=PP_ALIGN.RIGHT, fit=False)
    if cagr and n > 1:
        by = y + 0.15
        (x1, t1), (x2, t2) = tops[0], tops[-1]
        lw = 0.018
        for ax, t in ((x1, t1), (x2, t2)):
            rect(slide, ax - lw / 2, by, lw, t - by - 0.5, INK)
            rect(slide, ax - 0.07, t - 0.5, 0.14, 0.1, INK, MSO_SHAPE.ISOSCELES_TRIANGLE, rot=180)
        rect(slide, x1, by, x2 - x1, lw, INK)
        pw = 1.55
        p = rect(slide, (x1 + x2) / 2 - pw / 2, by - 0.17, pw, 0.36, RED, MSO_SHAPE.ROUNDED_RECTANGLE)
        p.adjustments[0] = 0.5
        text(slide, (x1 + x2) / 2 - pw / 2, by - 0.17, pw, 0.36, cagr, size=12, color=WHITE, bold=True,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, fit=False)


bar_chart_cagr = bar_chart  # backwards-compatible name


def hbars(slide, items, x, y, w, row_h=0.5, unit="", decimals=0, highlight=None, label_w=2.6):
    """Horizontal bars: items = [(label, value)], sorted as given. `highlight` index in red, others
    in tint; value printed at the bar end."""
    vmax = max(v for _, v in items) or 1
    bar_w = w - label_w - 0.8
    for i, (lab, v) in enumerate(items):
        ry = y + i * row_h
        text(slide, x, ry, label_w - 0.15, row_h, lab, size=13, anchor=MSO_ANCHOR.MIDDLE, min_size=10)
        bl = bar_w * v / vmax
        col = RED if (highlight is None or i == highlight) else TINTS[2]
        rect(slide, x + label_w, ry + row_h * 0.2, bl, row_h * 0.6, col)
        text(slide, x + label_w + bl + 0.08, ry, 0.9, row_h, f"{v:,.{decimals}f}{unit}", size=12, bold=True,
             anchor=MSO_ANCHOR.MIDDLE, fit=False)


def _wedge(slide, cx, cy, r, a0, a1, color):
    """Masking fan from the centre covering a0..a1 (deg, 0 = 12 o'clock, clockwise), built from
    <= 2.5 deg triangles for a smooth edge."""
    steps = max(1, int(math.ceil((a1 - a0) / 2.5)))
    da = (a1 - a0) / steps
    for k in range(steps):
        mid = a0 + da * (k + 0.5)
        tw = 2 * r * math.tan(math.radians(da / 2 + 0.3)) * 1.02
        m = math.radians(mid)
        bcx, bcy = cx + (r / 2) * math.sin(m), cy - (r / 2) * math.cos(m)
        rect(slide, bcx - tw / 2, bcy - r / 2, tw, r, color, MSO_SHAPE.ISOSCELES_TRIANGLE, rot=(180 + mid) % 360)


def donut(slide, values, cx, cy, r, colors=None, thickness=0.5, centre_label="", centre_sub="", bg=WHITE):
    """Smooth donut: wedge fans per segment, white separators, inner disc, bold centre label."""
    colors = colors or SERIES
    total = float(sum(values))
    a = 0.0
    for v, c in zip(values, colors):
        span = 360 * v / total
        _wedge(slide, cx, cy, r, a, a + span, c)
        a += span
    a = 0.0
    for v in values:
        rad = math.radians(a)
        sx, sy = cx + (r / 2) * math.sin(rad), cy - (r / 2) * math.cos(rad)
        rect(slide, sx - 0.015, sy - r / 2 - 0.01, 0.03, r + 0.02, bg, rot=a)
        a += 360 * v / total
    ir = r - thickness
    rect(slide, cx - ir, cy - ir, 2 * ir, 2 * ir, bg, MSO_SHAPE.OVAL)
    if centre_label:
        text(slide, cx - ir, cy - 0.35, 2 * ir, 0.5, centre_label, size=24, color=RED, bold=True,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, fit=False)
    if centre_sub:
        text(slide, cx - ir, cy + 0.15, 2 * ir, 0.3, centre_sub, size=11, color=MUTED,
             align=PP_ALIGN.CENTER, fit=False)


def legend(slide, items, x, y, w, colors=None, row_h=0.42, values=None):
    """Legend rows: square swatch, label, optional bold value right-aligned."""
    colors = colors or SERIES
    for i, lab in enumerate(items):
        ry = y + i * row_h
        rect(slide, x, ry + row_h / 2 - 0.09, 0.18, 0.18, colors[i % len(colors)])
        text(slide, x + 0.32, ry, w - 1.2, row_h, lab, size=13, anchor=MSO_ANCHOR.MIDDLE, min_size=10)
        if values:
            text(slide, x + w - 0.9, ry, 0.9, row_h, str(values[i]), size=13, bold=True,
                 align=PP_ALIGN.RIGHT, anchor=MSO_ANCHOR.MIDDLE, fit=False)


def kpi_ring(slide, cx, cy, r, frac, color=RED, label="", sub="", width_pt=10, bg=WHITE, track=GRID):
    """Smooth progress ring: native ellipse outline, track-coloured wedges over the open sector,
    background annulus clipping them, background inner disc. Hero ring: color=DARK, larger r."""
    lw = width_pt / 72.0
    rect(slide, cx - r, cy - r, 2 * r, 2 * r, None, MSO_SHAPE.OVAL, line=color, line_w=width_pt)
    if frac < 1:
        _wedge(slide, cx, cy, r + lw, 360 * frac, 360, track)
        ro = r + lw
        rect(slide, cx - ro, cy - ro, 2 * ro, 2 * ro, None, MSO_SHAPE.OVAL, line=bg, line_w=width_pt * 1.2)
    ir = r - lw / 2
    rect(slide, cx - ir, cy - ir, 2 * ir, 2 * ir, bg, MSO_SHAPE.OVAL)
    if label:
        text(slide, cx - r, cy - 0.3, 2 * r, 0.5, label, size=20, color=color, bold=True,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, fit=False)
    if sub:
        text(slide, cx - r - 0.3, cy + r + 0.12, 2 * r + 0.6, 0.5, sub, size=12, color=INK,
             align=PP_ALIGN.CENTER, fit=False)


__all__ = [n for n in dir() if not n.startswith("_") or n in ("_alpha",)]
