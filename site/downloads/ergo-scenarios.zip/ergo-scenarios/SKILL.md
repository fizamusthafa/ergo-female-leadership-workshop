---
name: ergo-scenarios
description: "Use when I ask what if, what happens to our result if something changes, for scenarios, a stress test, a downside or severe case, or the impact of a worse combined ratio, a storm, a nat-cat event or slower growth."
---

# Scenarios the ERGO way

Work only with the open workbook. Build a sheet called `Scenarios`. Never overwrite source data. Scenarios are illustrations of sensitivity, not forecasts: never call them a forecast or a prediction.

## Inputs (visible, editable cells at the top)

Put every assumption in a clearly labelled input cell with a light grey fill, so I can change it and watch the table update:

- Combined ratio change, in percentage points (default from my question, for example +2).
- Which units it applies to (default: all).
- Extra storm month: yes/no. If yes, size it from the data: the storm month's claims for the affected line minus the average of that line's other months in the same quarter. Show this calculation in its own cell.
- Growth change, if I mention it, as a % change to GWP; NEP moves in proportion.

## The scenario table

Columns: **Base**, **Downside**, **Severe**. Rows: NEP, Claims, Costs, Investment result, Operating result, Combined ratio, Change in operating result vs Base.

- **Base** = the quarter as reported in the workbook (use the `Data` table if it exists, otherwise the actual sheet).
- **Downside** = Base with the combined ratio change applied: extra claims = change in points x NEP.
- **Severe** = Downside plus the extra storm month (and any growth change I asked for).

Every cell is a formula pointing to the input cells and the data. No typed results.

## Presentation

- Number format EUR m with one decimal; ratios in % with one decimal.
- Highlight the "Change in operating result" row. Negative impacts in ERGO red `#BF1629`.
- Add a small clustered column chart of operating result for the three scenarios: Base in charcoal, the other two in red tones. Flat 2D, no gridlines, values labelled.
- Under the table write: "Sensitivity illustration based on the assumptions above. Not a forecast."

## When you finish

In chat, give the operating result in each scenario and the change versus Base in one sentence each. Then name the assumption that moves the result most, and invite me to change an input cell.
