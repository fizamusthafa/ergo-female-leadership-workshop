---
name: ergo-board-pack
description: "Use when I ask for a board pack or board deck, to turn notes, a report or a document into a board presentation, to find or sharpen the one message of a deck, to make the last slide say what we need from the board, or for a cue card or a 60-second spoken version of my board presentation. Not for restyling existing slides."
---

# Build an ERGO board pack

Use only the open presentation and the files I attach. Never invent a figure, name, date or decision. If something the structure needs is missing, write "Not in the source" and mention it in chat.

## Structure: five content slides, in this order

If the deck already has a title slide, keep it first and add the five slides after it.

1. **The message.** One full-sentence headline that answers "what should the board take away?", plus at most three supporting points. Example shape: "Growth ahead of plan; result held back by one storm and one structural issue".
2. **KPI strip.** Four or five tiles in a row: premiums (GWP), combined ratio, operating result, and one or two more that the source stresses. Each tile shows the actual value, plan and prior year, and the change as ▲ or ▼ with % or points. The first tile is the focus and uses ERGO red; the rest stay grey. Headline states what the KPIs say together.
3. **What changed and why.** Separate one-off effects from structural ones. Give each cause its own line with its size if the source has it.
4. **Risks and outlook.** Name each risk with what we are doing about it. State the outlook as an expectation in words. Do not put numbers on the outlook unless the source gives them.
5. **What we need from the board.** Title starts with "Decision needed:". State the ask, the amount and time frame, the conditions or guardrails, and the recommendation. If the source presents options, show them side by side.

If the deck was created from the ERGO board template, use its layouts: Title, KPI strip, Content, Two column, Decision.

## Speaker notes

Every slide gets speaker notes: what to say in about 45 seconds, the figures behind each statement, and the source line "Source: [file name]". Anything useful that did not fit on the slide goes here.

## Style

Follow the ERGO brand rules if the ergo-brand skill is available. Otherwise: white background, charcoal text, ERGO red `#BF1629` as the single accent, Segoe UI, no more than three bullets per slide. Keep any "Illustrative figures for training purposes" label on every slide.

## Sharpening an existing pack

When I ask for the one message, reply with one sentence of no more than 20 words, then update slide 1 to match. When I ask for the last slide to say what we need from the board, rewrite slide 5 so the decision, amount, timing and recommendation can be read in five seconds.

## Leave-behind

When I ask for a cue card, add one final slide titled "Cue card" with the five slide messages as numbered one-liners and the three numbers I must remember. When I ask for a 60-second version, write about 150 words in chat that I can say out loud, in plain spoken language, ending with the ask.

## When you finish

In chat, give the one-sentence message of the deck and list anything marked "Not in the source".
