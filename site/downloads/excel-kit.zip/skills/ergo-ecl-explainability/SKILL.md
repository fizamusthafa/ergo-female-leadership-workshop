---
name: ergo-ecl-explainability
description: "Use when I ask to explain, defend, bridge or walk through an ECL or provision number, prepare it for a risk committee, or ask what drives it or what changed and why."
---

# Make Weighted ECL defensible in a risk committee

Use the existing calculation (for example Model_Output). Use live formulas that point to it; never retype numbers. If no calculation exists yet, say so and stop.

## Output: a sheet called `ECL_Explainability`

1. **Headline**: total Weighted ECL in EUR m and as a share of EAD.
2. **By stage**: loans, EAD, Weighted ECL, share of ECL and coverage for Stage 1, 2 and 3, plus the share that comes from Stage 2 and Stage 3 together.
3. **Driver bridge**, in this order so the steps add up exactly to Weighted ECL:
   - Stage 1 view: every loan at its 12-month PD and segment LGD, Base scenario.
   - + **Stage effect**: Base ECL with staging minus the Stage 1 view.
   - + **Macro overlay**: scenario-weighted ECL before collateral stress minus Base ECL (PD and LGD shocks).
   - + **Collateral effect**: Weighted ECL minus scenario-weighted ECL before collateral stress (property price shocks on LGD).
   - = Weighted ECL. Add a check cell that confirms the bars add up.
   Also show the exposure-weighted LGD before and after collateral stress, and the total macro overlay (Base ECL → Weighted ECL).
4. **Waterfall chart** of the bridge: a native waterfall chart, or a stacked column chart with an invisible base series. Totals in charcoal `#242424`, increases in ERGO red `#BF1629`, values in EUR m, no gridlines, title stating the message.
5. **"What changed and why"**: a short narrative of four or five sentences. Lead with the number, then the biggest driver, then the macro and collateral effects with their sizes, then what would move the number most. Name the open data points from the controls check, if there is one. Plain language a board member can follow; no jargon without a short explanation.

## Tone and rules

- Factual and calm. Separate what the model shows from what is assumed.
- Every number in the narrative must match a cell on the sheet.
- Do not present scenarios as forecasts. Do not give accounting or regulatory advice.

## When you finish

In chat, give the one-sentence answer to "why is ECL this number?" and the question the committee is most likely to ask, with a suggested answer.
