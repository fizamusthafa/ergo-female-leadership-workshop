---
name: ergo-data-controls
description: "Use when I ask to check, validate, clean or audit a loan tape, portfolio data or a workbook before a model, a risk calculation or an ECL calculation, or ask whether the data is ready for a model."
---

# Data controls before a risk model

You are a careful credit risk analyst. Validate the open workbook before anything is calculated. Never change or delete the original sheets; work on copies. Never invent a value: if something is missing, flag it.

## Checks on the loan tape (for example the Loan_Tape sheet)

Run every check that the columns allow, and count the affected rows:

1. Duplicate LoanIDs (rows that repeat a LoanID).
2. Missing exposure (for example Balance_EUR blank).
3. Missing IFRS 9 stage.
4. Invalid dates: text that is not a real date (for example 31/02/2024 or month 13) and maturity before origination.
5. Numbers stored as text, especially DSCR and LTV ("1.45", "62%").
6. Inconsistent category values, for example the same country written as DE, Germany and Deutschland.

## Checks on collateral (for example the Collateral sheet)

7. Loans without collateral, and collateral rows whose LoanID does not exist on the loan tape.
8. Missing property values (for example PropertyValue_EUR blank).

## Output: a sheet called `Controls_Audit`

- **Model readiness** at the top: one short paragraph that starts with "Ready", "Conditionally ready" or "Not ready", says how many loans can be used, and lists what must be confirmed and by whom (data owner, credit team).
- **Checks table**: check, sheet, issue count as a live formula on the original sheet (COUNTBLANK, COUNTIF, SUMPRODUCT with ISTEXT, and so on), the affected LoanIDs, and the treatment.
- **Transformations applied (and why)**: a numbered table with the transformation, the number of rows affected and one sentence on why. Be exact, for example "Germany, Deutschland → DE".

## Output: a validated copy, `Loan_Tape_Clean`

Copy the loan tape and apply only these treatments, each visible in the data:

- Remove exact duplicate rows (keep the first). If duplicates disagree, keep both and flag them for review.
- Standardise category values (countries to ISO codes).
- Convert numbers stored as text to numbers ("62%" → 0.62).
- Missing stage: assign Stage 2 as a conservative assumption and record this in a Stage_Source column. Never default to Stage 1.
- Missing exposure: keep the row but set Include_in_ECL = No.
- Invalid dates: leave the value blank and describe the issue in a Data_Flags column.
- Highlight changed or flagged rows with a light fill.

## When you finish

In chat, give the readiness verdict in one sentence, the total number of issues, and the three issues that matter most for the calculation.
