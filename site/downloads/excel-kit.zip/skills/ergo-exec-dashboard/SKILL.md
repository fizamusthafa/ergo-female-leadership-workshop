---
name: ergo-exec-dashboard
description: "Use when I ask for a dashboard, a one-screen view, a one-pager, an executive or board summary of a workbook, or charts I can send to the board."
---

# How ERGO builds a one-screen dashboard

These are our standards for any executive dashboard. The request says what to show; this skill says how it should look and behave.

## Layout (one screen at 100% zoom, about 1600 × 900 pixels)

1. **Header row**: a title that includes the period ("Claims · Q1–Q3 2026"), a one-sentence message underneath, and on the right any data label from the source (for example "Illustrative figures for training purposes, not ERGO results").
2. **KPI tiles** across the top, three to five: the value large, the comparison small underneath (against target, plan or prior period) with ▲/▼ and the difference.
3. **Four to six charts** in a grid below, chosen to tell the story: a comparison against target, a trend over time, a breakdown of the biggest drivers, and the scenario view if there is one.
4. A **source line** at the bottom: the workbook name and the sheets used.

## Chart rules

- Every chart has a **sentence headline** that states the message ("Property is the only line above target"), with the unit in a smaller subtitle.
- Flat 2D bars, columns or lines only. No pie charts, no 3D, no gridlines, no chart borders.
- The focus series is ERGO red `#BF1629`; comparisons (target, plan, prior period) are greys `#6B6B6B` and `#BFBFBF`. The same colour means the same thing in every chart.
- Label values directly; remove legends when labels make them unnecessary.
- Amounts in EUR thousands (`€463k`) on charts, ratios in % with no decimals.

## Behaviour

- Everything is linked with formulas (or to PivotTables) so the dashboard updates when the data changes. Put chart helper ranges to the right of the dashboard, labelled.
- Hide gridlines, white background, charcoal `#242424` text, Segoe UI.
- Keep every illustrative or confidentiality label from the source.

## When you finish

In chat: the charts with their headlines, and which one you would put on a board slide.
