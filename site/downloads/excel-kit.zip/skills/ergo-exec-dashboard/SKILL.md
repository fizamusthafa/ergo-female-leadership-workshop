---
name: ergo-exec-dashboard
description: "Use when I ask for a dashboard, a one-screen view, a one-pager, an executive or board summary of a workbook, or charts I can send to the board."
---

# One-screen executive dashboard

Build a sheet called `Dashboard` from the open workbook. Use the `KPIs` and `Scenarios` sheets if they exist; otherwise calculate from the data with formulas. Never invent figures.

## Layout (fits on one screen at 100% zoom, about 1600 x 900 pixels)

1. **Header row**: a title with the period, for example "Q3 2026 at a glance", and on the right the label from the source data (for example "Illustrative figures for training purposes, not ERGO results").
2. **KPI tiles** across the top: GWP, combined ratio, operating result, and one more the data supports (for example policies). Each tile shows the value large, and the change versus plan and prior year small, with ▲/▼.
3. **Four to six charts** in a grid below. Choose the ones that tell the story, for example:
   - GWP by business unit, actual versus plan;
   - combined ratio by unit versus plan;
   - operating result bridge or comparison versus plan;
   - a monthly trend that shows the biggest swing in the quarter;
   - scenarios, if a `Scenarios` sheet exists.

## Chart rules

- Every chart has a **sentence headline** that says what it shows, for example "Property & Casualty drives the gap to plan", with the unit in a smaller subtitle.
- Flat 2D bars, columns or lines only. No pie charts, no 3D, no gridlines, no chart borders.
- Focus series in ERGO red `#BF1629`; plan and prior year in greys (`#6B6B6B`, `#BFBFBF`). Same colour means the same thing in every chart.
- Label values directly; remove legends where labels make them unnecessary.
- Number formats: EUR m with no decimals on charts, % with one decimal.

## Finish

- Hide gridlines on the sheet, set a white background, charcoal `#242424` text, Segoe UI.
- Add a source line at the bottom: the workbook name and sheet names used.
- Keep the dashboard linked to the data with formulas, so it updates when the data changes.

In chat, list the charts with their headlines and say which one you would put on a board slide.
