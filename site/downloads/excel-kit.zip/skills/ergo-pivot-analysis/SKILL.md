---
name: ergo-pivot-analysis
description: "Use when I ask to analyse, break down, slice, summarise or compare data by category, region, period or segment, to build PivotTables, or ask where a number comes from, what drives it or which areas stand out."
---

# How ERGO analyses data with PivotTables

These are our standards for any breakdown or driver analysis. The request says which questions to answer; this skill says how.

## Build it as real PivotTables

1. Use real Excel **PivotTables**, not static copies or hand-made summary tables, so anyone can re-slice them.
2. Source: the cleaned table (`<Sheet>_Clean`) if it exists. Exclude rows with `Include_in_Analysis = No` with a filter, and say so in a note.
3. Put all PivotTables for one question on one sheet called `Pivot_Analysis` (or the name I give), side by side with a blank column between them, each with a short title above it.
4. Sort categories by value, largest first. Time periods stay in time order.
5. Show the measure that answers the question (usually a sum), plus a count and a **% of total** column where it helps.
6. Number formats: EUR amounts without decimals, % with one decimal. Rename fields to plain words ("Incurred (EUR)", not "Sum of Incurred_EUR").
7. Add a slicer for the most useful dimension if the request asks for interactivity.

## Then turn the pivots into insight

Above the PivotTables write:

- **A one-sentence headline** that answers the question ("Property's loss ratio is driven by one storm in August").
- **The top three drivers**, each one line with the size in EUR or points and its share of the total, separating one-off events from trends.
- **What the pivots cannot tell us**, if anything (for example premium is not in the claims data, so a loss ratio by region needs the policy data too).

Small categories with fewer than 10 rows get the note "small sample".

## When you finish

In chat: the headline, the three drivers, and one follow-up question worth asking next.
