---
name: ergo-calculations
description: "Use when I ask to calculate KPIs, ratios, a model, a forecast-style or what-if view, scenarios, a sensitivity or a stress test in Excel, or ask what happens to a result if an assumption changes."
---

# How ERGO builds calculations that a reviewer can follow

These are our standards for any calculation, from a simple KPI table to a scenario model. The request says what to calculate; this skill says how to build it.

## Golden rules

1. **Live formulas only.** Every result is a formula a reviewer can click and trace. Never type a calculated number.
2. **Inputs live in one place.** Use the workbook's assumptions sheet if there is one; otherwise create `Inputs`. Input cells get a light grey fill (`#EFEFEF`) and a label. No hard-coded numbers inside formulas, except 0, 1 and 100.
3. **Use the cleaned data.** If `<Sheet>_Clean` tables exist, calculate from them and only from rows with `Include_in_Analysis = Yes`.
4. **Readable formulas.** Prefer SUMIFS, COUNTIFS, XLOOKUP or INDEX/MATCH and LET over long nested IFs. Reference table columns by name where possible.
5. **Guard the edges.** Wrap divisions in IFERROR or check for zero. Cap ratios and probabilities where the request asks for it, and say so.
6. **Check cells.** Add at least one reconciliation check (for example the sum of the parts equals the total, or row counts match the clean data) that shows `OK` or `Check`.

## Layout of the output sheet

- A **summary block** at the top: the three to five numbers that matter, each with its unit.
- The **main table** below: one row per item (for example per line of business), one column per measure, a total row. Totals are recalculated from their components (a total ratio is total numerator / total denominator, never an average of ratios).
- **Scenarios** side by side in their own shaded column groups, each scenario's parameters pulled from the inputs, then a **weighted** result if weights are given. Weights must add to 100%; show a check.

## Number formats

EUR with thousands separators and no decimals for amounts; ratios as % with one decimal; changes in percentage points as `+2.1 pts`; frequencies with one decimal and their unit in the header ("per 1,000 policies").

## Documentation: an `Assumptions_Documentation` sheet

One row per topic, in plain language: scope (which rows, what is excluded), each measure and its formula, each scenario parameter and how it is applied, weights, caps, limitations, and how to change an input to see the effect.

## When you finish

In chat: the headline result, the one assumption that moves it most, and an invitation to change an input cell and watch the result update. Call scenarios sensitivities, never forecasts.
