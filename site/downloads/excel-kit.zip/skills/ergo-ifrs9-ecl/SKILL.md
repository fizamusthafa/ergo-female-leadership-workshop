---
name: ergo-ifrs9-ecl
description: "Use when I ask to calculate ECL, expected credit loss, IFRS 9 provisions, or a staged or scenario-weighted loss estimate for a loan book, or ask what the provision would be under different scenarios."
---

# Scenario-weighted ECL, IFRS 9 style, that a reviewer can follow

Build the calculation with live Excel formulas only (INDEX/MATCH or XLOOKUP, SUMPRODUCT, MIN/MAX). Never type a result. Use the validated loan copy (for example Loan_Tape_Clean) if it exists, and only rows marked Include_in_ECL = Yes. Never change the input sheets.

## Mappings

- Segment → Risk_Params: Base_PD_12m, LGD, EAD_CCF, Stage2_PD_Multiplier, Stage3_LGD_Addon.
- Scenario → Macro_Scenarios: Weight, PD_Multiplier, LGD_Addon, CRE_Price_Shock. Weights must add to 100%; say so if they don't.
- LoanID → Collateral: PropertyType and PropertyValue_EUR. PropertyType → HaircutPolicy: Haircut.

## Method

1. **EAD** = drawn balance + undrawn amount × EAD_CCF.
2. **Stage PD**: Stage 1 = Base_PD_12m. Stage 2 = Base_PD_12m × Stage2_PD_Multiplier. Stage 3 = 100%.
3. **Scenario PD** = stage PD × PD_Multiplier, capped between 0% and 100%. Stage 3 stays at 100%.
4. **LGD before collateral stress** = segment LGD + scenario LGD_Addon, plus Stage3_LGD_Addon for Stage 3 loans. Cap 0–100%.
5. **Collateral**: collateral shortfall = max(0, 1 − PropertyValue × (1 − Haircut) / EAD). Under each scenario, reduce the property value by CRE_Price_Shock; the increase in shortfall versus today's prices is the **collateral LGD impact**.
6. **LGD** = min(100%, LGD before collateral stress + collateral LGD impact). Loans without collateral or property value get no collateral impact; flag them.
7. **Scenario ECL** = EAD × scenario PD × scenario LGD. **Weighted_ECL** = Σ weight × scenario ECL.

## Output: a sheet called `Model_Output`

- A summary block at the top: one column per scenario with weight, PD multiplier, LGD add-on, price shock (all linked to Macro_Scenarios) and total ECL; then Weighted ECL, total EAD, coverage (Weighted ECL / EAD) and the number of loans.
- One row per loan: LoanID, segment, stage (and where the stage came from), EAD and its parts, PD, LGD, collateral values, then for each scenario: PD, LGD before collateral, collateral LGD impact, LGD, ECL; and Weighted_ECL.
- A total row. Shade each scenario's columns differently. Freeze the LoanID column.

## Output: a sheet called `Assumptions_Documentation`

Explain in plain language, one row per topic: scope (which loans, which excluded), EAD, PD per stage, scenario overlays, caps, LGD and collateral logic, weights, mappings, limitations (12-month horizon, no discounting, Stage 2 multiplier as a lifetime proxy) and how to change an assumption.

## When you finish

In chat: Weighted ECL, ECL per scenario, coverage, and the single assumption that moves the result most. Invite me to change a weight on Macro_Scenarios and watch it update. Never call a scenario a forecast.
