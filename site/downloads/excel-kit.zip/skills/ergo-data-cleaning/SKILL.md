---
name: ergo-data-cleaning
description: "Use when I ask to clean, check, validate, tidy or prepare data in a workbook, find data-quality issues, or ask whether data is ready for analysis, a model or a report."
---

# How ERGO cleans data before anyone analyses it

These are our standards for any data cleaning, whatever the data. The request tells you which sheets and checks matter; this skill tells you how to do it.

## Golden rules

1. **Never touch the original.** Leave every source sheet exactly as it is. Write cleaned data to new sheets named `<Sheet>_Clean` and format them as Excel tables.
2. **Never invent data.** You may standardise, convert and derive from values in the same row, but you never fill a gap with a guess. If something is missing, flag it.
3. **Every change is visible.** Each cleaned row that was changed or flagged gets a short note in a `Data_Flags` column and a light amber fill (`#FFF4E5`).
4. **Exclude, don't delete.** Rows that cannot be used get `Include_in_Analysis = No` and stay in the clean table, so totals can be reconciled.

## Checks to run (whatever applies to the columns)

- Duplicates: exact duplicate rows, and repeated IDs with different values.
- Blanks in key fields (IDs, amounts, dates, categories).
- Numbers stored as text, including German formats (`1.234,50` means 1234.50, `12 %` means 0.12).
- Invalid dates (`31.02.2026`, month 13) and impossible sequences (an end date before a start date, a report date before the event date).
- Inconsistent category names: compare against a lookup or reference list if the workbook has one, otherwise against the most common spelling. Watch for abbreviations, translations and trailing spaces.
- Broken references between sheets (IDs that do not exist in the related sheet, in both directions).
- Implausible values: negative amounts, zeros where a value is required, extreme outliers. Flag them; do not change them.

## Treatments

| Issue | Treatment |
|---|---|
| Exact duplicate rows | Remove, keep the first |
| Same ID, different values | Keep both, flag for review |
| Text numbers and text dates in a known format | Convert |
| Inconsistent names | Standardise to the reference list |
| Invalid dates | Leave blank, describe in Data_Flags |
| Missing key amounts | `Include_in_Analysis = No` |
| Value derivable from the same row (for example earned premium from annual premium) | Derive, and say so in Data_Flags |
| Broken references, negatives, outliers | Keep, flag |

## Output: a `Data_Quality` sheet

1. **Readiness verdict** at the top, one short paragraph starting with "Ready", "Ready with caveats" or "Not ready": how many rows can be used, what is excluded, what must be confirmed and by whom.
2. **Checks table**: check, sheet, issue count as a **live formula on the original sheet** (COUNTBLANK, COUNTIF against the lookup list, SUMPRODUCT with ISTEXT, and so on), affected IDs, treatment.
3. **Total issues** as a sum of the counts.
4. **Transformations applied (and why)**: numbered, with the number of rows affected and one sentence on why. Be exact ("Bavaria, BY → Bayern").

## When you finish

In chat: the verdict in one sentence, the total number of issues, and the three issues that matter most for the analysis that follows.
