---
name: ergo-insurance-kpis
description: "Use when I ask how we are doing, how business units or lines of business perform against plan or last year, for KPIs, a KPI table or a performance review of insurance figures, or why a unit is ahead or behind plan."
---

# Insurance KPIs the ERGO way

Work only with the open workbook. Never change the original export sheets. Never invent figures; if a KPI needs data that is missing, show "Not in the source".

## Step 1: tidy the data into a sheet called `Data`

- Read the actual, plan and prior-year sheets, whatever their header names. Match columns by meaning: business unit, line of business, period, gross written premium (GWP), net earned premium (NEP), claims, costs, investment result, policies.
- Skip title rows, unit rows and blank rows. Note the units (usually EUR m and thousand policies).
- Build one Excel table named `Data` with the columns: Scenario (Actual / Plan / Prior year), Unit, Line, Period, GWP, NEP, Claims, Costs, Investment, Policies.
- Tell me in chat how many rows came from each sheet.

## Step 2: build a sheet called `KPIs`

One row per business unit plus a Group total row, with formulas (SUMIFS on the `Data` table), never typed values:

| KPI | Definition |
|---|---|
| GWP | Sum of gross written premium |
| GWP vs plan, % | Actual / Plan - 1 |
| GWP vs prior year, % | Actual / Prior year - 1 |
| Loss ratio | Claims / NEP |
| Expense ratio | Costs / NEP |
| Combined ratio | Loss ratio + Expense ratio; below 100% means an underwriting profit |
| Combined ratio vs plan, pts | Actual - Plan, in percentage points |
| Operating result | NEP - Claims - Costs + Investment |
| Operating result vs plan and vs prior year | Difference in EUR m |
| Policies | Policies in the last period of the quarter (a stock, not a sum) |

Format: EUR m with one decimal, ratios as % with one decimal, changes in points with a sign ("+2.1 pts"). A worse combined ratio is a higher number: colour it red. Better results green. Use ERGO red `#BF1629` for header accents and charcoal `#242424` text.

Add a column **Status** with "Ahead", "On plan" (within ±0.5 pts combined ratio and ±1% GWP) or "Behind", based on operating result versus plan.

## Step 3: summary

Above the table, write three short lines with formulas or clearly sourced numbers: where we lead, where we lag, and the biggest single driver of the gap to plan.

## Step 4: sheet called `Definitions`

List each KPI with its definition and formula, the units, and this note: "Simplified training definitions. For Life & Health the combined ratio is shown for comparability within this workbook only."

## Answering follow-up questions

When I ask why a unit is ahead or behind, answer in plain language in three to five sentences, citing the cells or lines you used. Separate one-off effects (for example a single month with very high claims) from trends across months.

## When you finish

In chat, name the new sheets, the Group combined ratio versus plan and the unit that drives the gap.
