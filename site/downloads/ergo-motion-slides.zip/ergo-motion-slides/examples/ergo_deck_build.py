"""Write the sample slides + spec.json into ./ergo_sample (run from a working folder), then:
python <skill>/scripts/build_live_deck.py ergo_sample/spec.json "ergo_sample/ERGO motion sample.pptx" """
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "scripts")); sys.path.insert(0, HERE)
from block_shell import page
import ergo_motion as M
from ergo_deck_content import SLIDES, TITLES, ALTS

key = "ergo_sample"; os.makedirs(key, exist_ok=True)
spec = {"title": "ERGO Motion sample", "slides": []}
for i, fn in enumerate(SLIDES):
    html = page(TITLES[i], fn(i + 1), css=M.CSS, js=M.JS, theme=M.THEME, lang="en", components=True)
    f = f"slide{i + 1}.html"; open(os.path.join(key, f), "w", encoding="utf8").write(html)
    spec["slides"].append({"html": f, "title": TITLES[i], "alt": ALTS[i]})
json.dump(spec, open(os.path.join(key, "spec.json"), "w", encoding="utf8"), ensure_ascii=False, indent=1)
print("written", [os.path.getsize(os.path.join(key, f"slide{i + 1}.html")) // 1024 for i in range(len(SLIDES))], "KB")
