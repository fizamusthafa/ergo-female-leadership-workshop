"""Sample ERGO Motion slides (appendix style): divider, agenda, KPI tiles + pillars, bar chart + side panel,
timeline + takeaway, donut. Figures are ILLUSTRATIVE - replace with real, sourced numbers before use."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
import ergo_motion as M

EVENT = "AI working session – Agents in claims"
SRC = "Illustrative figures. Source: pilot telemetry, November 2026."

def s_divider(p):
    return M.divider("Appendix", "Detail behind the main story", label="Section 2", number=2)

def s_agenda(p):
    return (M.header("Appendix overview") + M.body(M.agenda(
        [("Pilot results", "Usage and value"), ("Use cases", "Claims intake"), ("Guardrails", "Security"), ("Next steps", "Plan")],
        active=0, detail=["Sessions and adoption", "Time saved per file"])) + M.footer(p, EVENT))

def s_kpis(p):
    return (M.header("Pilot results: adoption is broad", kicker="Appendix")
            + M.body(M.kpi_tiles([("Active users", 1240, "", 0, "per month"), ("Time saved", 18, "%", 0, "per claim file"),
                                  ("Satisfaction", 8.4, "", 1, "out of 10")]),
                     M.pillars([("document-check", "Intake", "Documents are read and checked in minutes."),
                                ("headset", "Service", "Agents answer status questions around the clock."),
                                (None, "Experts", "Specialists stay in the loop for every decision.")]))
            + M.footer(p, EVENT, SRC))

def s_chart(p):
    return (M.header("Agent use is growing steadily", "Monthly sessions, 2026", kicker="Appendix")
            + M.body(M.bar_chart(["Q1", "Q2", "Q3", "Q4"], [4.2, 5.1, 6.4, 7.9], title="Monthly agent sessions",
                                 unit="(thousand)", decimals=1, cagr="23% CAGR"))
            + M.side_panel("Observations", "What drives the growth", ["Claims teams use agents daily",
                           "Triage time drops first", "Next: one more line of business"])
            + M.footer(p, EVENT, SRC))

def s_timeline(p):
    return (M.header("From pilot to scale in four steps", kicker="Appendix")
            + M.body(M.timeline([("Q4 2026", "Pilot in claims intake"), ("Q1 2027", "Second line of business"),
                                 ("Q2 2027", "Rollout to all teams"), ("Q3 2027", "Review and scale")], now=0),
                     M.takeaway("Start small, prove value, then scale."), align="spread")
            + M.footer(p, EVENT))

def s_donut(p):
    return (M.header("Where the time goes today", kicker="Appendix")
            + M.body(M.donut([("Document checks", 45), ("Status questions", 25), ("Expert review", 20), ("Other", 10)],
                             "100%", "of handling time"), align="center")
            + M.footer(p, EVENT, SRC))

SLIDES = [s_divider, s_agenda, s_kpis, s_chart, s_timeline, s_donut]
TITLES = ["Appendix", "Appendix overview", "Pilot results: adoption is broad", "Agent use is growing steadily",
          "From pilot to scale in four steps", "Where the time goes today"]
ALTS = ["Section divider: Appendix.", "Agenda with four tiles; Pilot results active.",
        "Three red KPI tiles and three grey pillars. Illustrative figures.",
        "Bar chart Q1 to Q4 with a 23% CAGR bracket and an observations panel. Illustrative figures.",
        "Timeline with four steps and a takeaway band.", "Donut chart of handling time with legend. Illustrative figures."]
