#!/usr/bin/env python3
"""Edit the live (HTML) slides of an EXISTING .pptx - works on decks built by this skill and on
interactive slides PowerPoint Copilot created. Everything else in the deck (static slides, notes,
order, layouts) is kept byte for byte.

  python edit_live_deck.py extract <deck.pptx> <folder>
      -> <folder>/slideN.html for every live slide (N = position in the deck), <folder>/map.json
  ... edit the HTML files (text, numbers, colours, motion) ...
  python edit_live_deck.py update <deck.pptx> <folder> <new deck.pptx>
      -> writes the changed HTML back into its slide and renders a fresh picture for each changed slide

The slide engine cannot read or change these blocks (it lists them as contentApps, addressable:false),
so this script is the only way to edit them. Publish the result as a NEW file; the original stays as is.
"""
import hashlib, json, os, posixpath, re, sys, tempfile, zipfile
from lxml import etree

NS = {"p": "http://schemas.openxmlformats.org/presentationml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
      "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
      "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
      "we": "http://schemas.microsoft.com/office/webextensions/webextension/2010/11"}
RT_WEBEXT = "http://schemas.microsoft.com/office/2011/relationships/webextension"
RT_IMAGE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"

def _rels(z, part):
    d, b = posixpath.split(part)
    rp = posixpath.join(d, "_rels", b + ".rels")
    if rp not in z.namelist(): return []
    out = []
    for r in etree.fromstring(z.read(rp)).findall("rel:Relationship", NS):
        out.append((r.get("Id"), r.get("Type"), posixpath.normpath(posixpath.join(d, r.get("Target")))))
    return out

def live_slides(z):
    """[(position, slide_part, webext_part, image_part, title, alt)] in deck order."""
    pres = etree.fromstring(z.read("ppt/presentation.xml"))
    prels = {i: t for i, _, t in _rels(z, "ppt/presentation.xml")}
    out = []
    for pos, sid in enumerate(pres.findall(".//p:sldIdLst/p:sldId", NS), 1):
        sp = prels[sid.get(f"{{{NS['r']}}}id")]
        rels = _rels(z, sp)
        we = [t for _, ty, t in rels if ty == RT_WEBEXT]
        if not we: continue
        x = etree.fromstring(z.read(sp))
        title = "".join(x.xpath('.//p:sp[.//p:ph[@type="title" or @type="ctrTitle"]]//a:t/text()', namespaces=NS)).strip()
        alt = (x.xpath('.//p:graphicFrame//p:cNvPr/@descr', namespaces=NS) or [""])[0]
        img = [t for _, ty, t in _rels(z, we[0]) if ty == RT_IMAGE]
        out.append((pos, sp, we[0], img[0] if img else None, title, alt))
    return out

def read_html(z, we_part):
    prop = etree.fromstring(z.read(we_part)).find(".//we:property[@name='contentBlockHtml']", NS)
    return json.loads(prop.get("value")) if prop is not None else None

def extract(deck, folder):
    os.makedirs(folder, exist_ok=True)
    z = zipfile.ZipFile(deck); m = []
    for pos, sp, we, img, title, alt in live_slides(z):
        html = read_html(z, we)
        if html is None: continue
        f = f"slide{pos}.html"
        open(os.path.join(folder, f), "w", encoding="utf8").write(html)
        m.append({"slide": pos, "html": f, "title": title, "alt": alt, "webextension": we, "picture": img,
                  "sha1": hashlib.sha1(html.encode()).hexdigest()})
    json.dump({"deck": os.path.basename(deck), "live_slides": m}, open(os.path.join(folder, "map.json"), "w", encoding="utf8"), ensure_ascii=False, indent=1)
    print(f"{len(m)} live slides extracted to {folder}: " + ", ".join(x['html'] for x in m))

def update(deck, folder, out):
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import build_live_deck as B
    from PIL import Image
    mp = json.load(open(os.path.join(folder, "map.json"), encoding="utf8"))
    z = zipfile.ZipFile(deck); new = {}
    for s in mp["live_slides"]:
        path = os.path.join(folder, s["html"]); html = open(path, encoding="utf8").read()
        if hashlib.sha1(html.encode()).hexdigest() == s["sha1"]: continue
        issues = [i for i in B.check(path) if not i.startswith("content does not fit")]
        if issues: sys.exit(f"slide {s['slide']}: " + "; ".join(issues))
        x = etree.fromstring(z.read(s["webextension"]))
        x.find(".//we:property[@name='contentBlockHtml']", NS).set("value", json.dumps(html))
        new[s["webextension"]] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
        if s["picture"]:
            with tempfile.TemporaryDirectory(dir=folder) as td:
                png = os.path.join(td, "p.png"); B.snapshot(path, png)
                im = Image.open(png); fmt = "JPEG" if s["picture"].lower().endswith((".jpg", ".jpeg")) else "PNG"
                import io; buf = io.BytesIO(); (im.convert("RGB") if fmt == "JPEG" else im).save(buf, fmt, optimize=True)
                new[s["picture"]] = buf.getvalue()
        print(f"slide {s['slide']}: updated")
    if not new: print("no HTML changed - nothing to do"); return
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as o:
        for i in z.infolist():
            o.writestr(i, new.get(i.filename, z.read(i.filename)))
    print("saved", out)

if __name__ == "__main__":
    if len(sys.argv) >= 4 and sys.argv[1] == "extract": extract(sys.argv[2], sys.argv[3])
    elif len(sys.argv) >= 5 and sys.argv[1] == "update": update(sys.argv[2], sys.argv[3], sys.argv[4])
    else: sys.exit(__doc__)
