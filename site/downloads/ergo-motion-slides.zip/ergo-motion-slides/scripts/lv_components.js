/* Live Slides web components - reusable custom elements for PowerPoint content blocks.
   Paste this file's content into the slide's <script> (the builder can do it: "components": true in the spec).
   Every element: shadow DOM with its own styles, no external resources, honours window.LV_SNAPSHOT
   (final state for the fallback picture) and prefers-reduced-motion, re-animates on lv:play.
   Colours come from CSS custom properties on the host page (--dark, --bar, --tint, --ink, --mut)
   with fallbacks, so any theme works. */
(function () {
  const SNAP = !!window.LV_SNAPSHOT;
  const REDUCE = !!(window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches);
  const still = () => SNAP || REDUCE;
  const ease = p => 1 - Math.pow(1 - p, 3);
  /* timer-based tween (rAF stalls in headless rendering and in some hosts) */
  function tween(ms, delay, step) {
    if (still()) { step(1); return; }
    const t0 = performance.now() + (delay || 0);
    (function tick() { const p = Math.max(0, Math.min(1, (performance.now() - t0) / ms)); step(ease(p)); if (p < 1) setTimeout(tick, 16); })();
  }
  const nf = (v, d, lang) => new Intl.NumberFormat(lang || window.LV_LANG_JS || "de", { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }).format(v);
  const BASE = ':host{display:block;color:var(--ink,#1B1F2A);font-family:inherit}*{box-sizing:border-box}';
  function define(name, cls) { if (!customElements.get(name)) customElements.define(name, cls); }
  /* all components replay together when the page plays its motion */
  addEventListener("lv:play", () => document.querySelectorAll("*").forEach(el => el.lvPlay && el.lvPlay()));

  /* <lv-ring value="72" max="100" label="monatlich aktiv" suffix=" %" decimals="0" size="1">  progress ring with count-up */
  define("lv-ring", class extends HTMLElement {
    connectedCallback() {
      if (this.shadowRoot) return;
      const r = this.attachShadow({ mode: "open" });
      r.innerHTML = `<style>${BASE}
        .w{display:flex;flex-direction:column;align-items:center;gap:.4em}
        .b{position:relative;width:calc(11em * var(--s,1));aspect-ratio:1}
        svg{width:100%;height:100%;transform:rotate(-90deg)}
        .tr{stroke:var(--tint,#C9D6EA)} .v{stroke:var(--bar,#0078D4);stroke-linecap:round}
        .n{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:calc(2.6em * var(--s,1));color:var(--dark,#0B1F44);font-variant-numeric:tabular-nums}
        .l{font-size:1.1em;color:var(--mut,#5B6475);text-align:center}</style>
        <div class="w"><div class="b"><svg viewBox="0 0 120 120" aria-hidden="true"><circle class="tr" cx="60" cy="60" r="52" fill="none" stroke-width="12"/>
        <circle class="v" cx="60" cy="60" r="52" fill="none" stroke-width="12" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/></svg>
        <div class="n"></div></div><div class="l"></div></div>`;
      this.style.setProperty("--s", this.getAttribute("size") || 1);
      r.querySelector(".l").textContent = this.getAttribute("label") || "";
      this.setAttribute("role", "img");
      this.setAttribute("aria-label", `${this.getAttribute("label") || ""}: ${this.getAttribute("value")}${this.getAttribute("suffix") || ""}`);
      this.lvPlay();
    }
    lvPlay() {
      const r = this.shadowRoot; if (!r) return;
      const v = Number(this.getAttribute("value")), max = Number(this.getAttribute("max") || 100), d = Number(this.getAttribute("decimals") || 0);
      const suf = this.getAttribute("suffix") || "", c = r.querySelector(".v"), n = r.querySelector(".n");
      tween(1300, Number(this.getAttribute("delay") || 200), p => { c.setAttribute("stroke-dashoffset", 100 - 100 * Math.min(1, v / max) * p); n.textContent = nf(v * p, d) + suf; });
    }
  });

  /* <lv-spark values="320,410,380,520,610,700" labels="Mai,Jun,Jul,Aug,Sep,Okt" unit="">  line that draws itself, first and last value printed */
  define("lv-spark", class extends HTMLElement {
    connectedCallback() {
      if (this.shadowRoot) return;
      const vals = (this.getAttribute("values") || "").split(",").map(Number), labs = (this.getAttribute("labels") || "").split(",");
      const W = 600, H = 220, P = 18, max = Math.max(...vals) * 1.1, n = vals.length;
      const pts = vals.map((v, i) => [P + i * (W - 2 * P) / (n - 1), H - P - (v / max) * (H - 2 * P)]);
      const unit = this.getAttribute("unit") || "";
      const r = this.attachShadow({ mode: "open" });
      r.innerHTML = `<style>${BASE}
        svg{width:100%;height:auto;overflow:visible}
        .base{stroke:var(--line,#D5DCE8)} .ln{stroke:var(--bar,#0078D4);fill:none;stroke-width:4;stroke-linejoin:round;stroke-linecap:round}
        .dot{fill:var(--bar,#0078D4)} .end{fill:var(--dark,#0B1F44)}
        text{font:inherit;font-size:20px;fill:var(--mut,#5B6475)} .val{font-weight:700;fill:var(--ink,#1B1F2A);font-size:22px}
        .fade{transition:opacity .4s}</style>
        <svg viewBox="0 -30 ${W} ${H + 60}" role="img" aria-label="${this.getAttribute("aria-label") || ""}">
          <line class="base" x1="${P}" x2="${W - P}" y1="${H - P}" y2="${H - P}"/>
          <polyline class="ln" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100" points="${pts.map(p => p.join(",")).join(" ")}"/>
          ${pts.map((p, i) => `<circle class="dot fade ${i === n - 1 ? "end" : ""}" data-i="${i}" cx="${p[0]}" cy="${p[1]}" r="${i === n - 1 ? 9 : 6}" opacity="0"/>`).join("")}
          ${labs.map((l, i) => `<text x="${pts[i][0]}" y="${H + 14}" text-anchor="middle">${l}</text>`).join("")}
          <text class="val fade" opacity="0" x="${pts[0][0]}" y="${pts[0][1] - 18}" text-anchor="start">${nf(vals[0])}${unit}</text>
          <text class="val fade" opacity="0" x="${pts[n - 1][0]}" y="${pts[n - 1][1] - 20}" text-anchor="end">${nf(vals[n - 1])}${unit}</text>
        </svg>`;
      this.lvPlay();
    }
    lvPlay() {
      const r = this.shadowRoot; if (!r) return;
      const ln = r.querySelector(".ln"), dots = [...r.querySelectorAll(".dot")], vals = [...r.querySelectorAll(".val")], n = dots.length;
      tween(1400, Number(this.getAttribute("delay") || 300), p => {
        ln.setAttribute("stroke-dashoffset", 100 - 100 * p);
        dots.forEach((d, i) => d.setAttribute("opacity", p >= i / (n - 1) - 0.001 ? 1 : 0));
        vals.forEach((v, i) => v.setAttribute("opacity", i === 0 || p >= 1 ? 1 : 0));
      });
    }
  });

  /* <lv-flip front-title="Vorher" front="..." back-title="Nachher" back="...">  card that flips on click (Enter/Space too) */
  define("lv-flip", class extends HTMLElement {
    connectedCallback() {
      if (this.shadowRoot) return;
      const g = a => this.getAttribute(a) || "";
      const r = this.attachShadow({ mode: "open" });
      r.innerHTML = `<style>${BASE}
        :host{perspective:1600px;height:100%}
        button{all:unset;display:block;width:100%;height:100%;cursor:pointer}
        button:focus-visible{outline:.2em solid var(--bar,#0078D4);outline-offset:.2em}
        .in{position:relative;width:100%;height:100%;min-height:9em;transform-style:preserve-3d;transition:transform .6s cubic-bezier(.3,.7,.2,1)}
        :host([flipped]) .in{transform:rotateY(180deg)}
        .f{position:absolute;inset:0;backface-visibility:hidden;padding:1.4em 1.6em;display:flex;flex-direction:column;gap:.5em;justify-content:center;box-shadow:0 .2em .8em rgba(0,0,0,.08)}
        .a{background:#fff} .z{background:var(--dark,#0B1F44);color:#fff;transform:rotateY(180deg)}
        .t{font-size:.9em;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--accent,#005A9E)} .z .t{color:var(--onDark,#9CC9F5)}
        .x{font-size:1.5em;font-weight:700;line-height:1.25} .h{font-size:.85em;color:var(--mut,#5B6475);margin-top:auto} .z .h{color:var(--tint,#C9D6EA)}</style>
        <button aria-pressed="false"><div class="in">
          <div class="f a"><span class="t">${g("front-title")}</span><span class="x">${g("front")}</span><span class="h">${g("hint") || "Klicken zum Umdrehen"}</span></div>
          <div class="f z"><span class="t">${g("back-title")}</span><span class="x">${g("back")}</span><span class="h">${g("hint-back") || "Klicken zum Zurückdrehen"}</span></div>
        </div></button>`;
      const b = r.querySelector("button");
      b.addEventListener("click", () => { const on = !this.hasAttribute("flipped"); this.toggleAttribute("flipped", on); b.setAttribute("aria-pressed", String(on)); });
    }
  });

  /* <lv-reveal> children appear one by one on each click/Enter on the element (presenter-paced fragments).
     Shows everything in the picture. */
  define("lv-reveal", class extends HTMLElement {
    connectedCallback() {
      if (this._init) return; this._init = true;
      const items = [...this.children]; this.tabIndex = 0; this.style.cursor = "pointer";
      const show = k => items.forEach((el, i) => { el.style.transition = "opacity .4s, transform .4s"; el.style.opacity = i < k ? 1 : .12; el.style.transform = i < k ? "none" : "translateY(.4em)"; });
      let k = still() ? items.length : 1; show(k);
      const next = () => { k = k >= items.length ? 1 : k + 1; show(k); };
      this.addEventListener("click", next);
      this.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); next(); } });
      this.lvPlay = () => { if (!still()) { k = 1; show(k); } };
    }
  });
})();
