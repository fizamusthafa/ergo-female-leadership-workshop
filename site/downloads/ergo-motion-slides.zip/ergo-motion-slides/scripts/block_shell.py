"""Shell for PowerPoint content-block HTML (Live Slides).

page(title, body, css="", js="", theme="microsoft", lang="de") -> full self-contained HTML.
The shell carries: viewport units, theme tokens, base + component CSS, and the JS helpers
fitPage/scheduleFit (auto-scale to the slide frame), initGroup (single choice tabs),
initToggles (multi-select), fmt (number format), barChart (horizontal bars from data).
Body = the slide's markup. css/js = slide-specific extras. No external resources ever.
"""

THEMES = {
    # role tokens: ink text, mut secondary text, dark = primary dark fill (selected / panels),
    # accent = eyebrow + tag text, bar = data/progress fill, tint = light fill, tint2 = border/track,
    # onDark = tag text on dark, line = hairlines, bg = slide ground, font = font stack
    "microsoft": dict(ink="#1B1F2A", mut="#5B6475", dark="#0B1F44", accent="#005A9E", bar="#0078D4",
                      tint="#C9D6EA", tint2="#A9BEDC", onDark="#9CC9F5", line="#D5DCE8", bg="#F2F4F8",
                      font='"Segoe UI", Calibri, sans-serif'),
    "ergo": dict(ink="#1E1E1E", mut="#615E5C", dark="#7A0E1C", accent="#BF1528", bar="#BF1528",
                 tint="#EDE9E6", tint2="#D9D4D1", onDark="#F2C4C9", line="#E3DFDC", bg="#F4F2F1",
                 font='Arial, "Helvetica Neue", sans-serif'),
    "neutral": dict(ink="#212121", mut="#5F6368", dark="#36454F", accent="#36454F", bar="#028090",
                    tint="#E3E8EA", tint2="#C5CDD1", onDark="#BFE3E6", line="#DDE2E4", bg="#F2F2F2",
                    font='Calibri, Arial, sans-serif'),
}

_HEAD = r'''<!DOCTYPE html>
<html lang="{lang}"><head><meta charset="utf-8"><title>{title}</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script>
(function () {
  function units() {
    const s = document.documentElement.style;
    s.setProperty("--vw", innerWidth / 100 + "px");
    s.setProperty("--vh", innerHeight / 100 + "px");
  }
  units();
  addEventListener("resize", units);
})();
</script>
<style>
:root{--vw:1vw;--vh:1vh;--ink:{ink};--mut:{mut};--dark:{dark};--accent:{accent};--bar:{bar};--tint:{tint};--tint2:{tint2};--onDark:{onDark};--line:{line};--bg:{bg};
--gap:min(1.6vw,2.84vh);--gap-s:min(.9vw,1.6vh);--pad:min(2.2vw,3.9vh);
--safe-t:4.5vh;--safe-r:5vw;--safe-b:6vh;--safe-l:5vw}
*,*::before,*::after{box-sizing:border-box}
button,input,select,textarea{font:inherit}
body{font-size:min(calc(1.3*var(--vw)),calc(2.31*var(--vh)));line-height:1.3;color:var(--ink);font-family:{font}}
html,body,.viewport{width:100%;height:100%;margin:0;overflow:hidden}
.viewport{position:fixed;inset:0;background:var(--bg)}
.page{width:100%;min-width:0;height:100%;min-height:0;max-width:none;margin:0;padding:var(--safe-t) var(--safe-r) var(--safe-b) var(--safe-l);
 transform-origin:top left;position:relative;display:flex;flex-direction:column;gap:var(--gap)}
.overlay{position:absolute;inset:0;z-index:1000;pointer-events:none}
p{margin:0}
/* type */
.eyebrow{margin:0;font-size:calc(1.25*var(--vw));font-weight:700;letter-spacing:.14em;color:var(--accent);text-transform:uppercase;line-height:1.3}
h1{margin:0;font-size:calc(2.9*var(--vw));font-weight:700;line-height:1.2;color:var(--ink);padding-bottom:.08em}
h2{margin:0;font-size:calc(1.9*var(--vw));font-weight:700;line-height:1.2}
.tag{font-size:calc(1.25*var(--vw));font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--accent);line-height:1.3}
.mut{color:var(--mut);font-size:calc(1.46*var(--vw));line-height:1.35}
.big{font-size:calc(2.1*var(--vw));font-weight:700;line-height:1.25}
.src{font-size:calc(1.25*var(--vw));color:var(--mut);flex:none}
/* layout */
.head{display:flex;flex-direction:column;gap:min(.5vw,.9vh);flex:none}
.main{flex:1 1 auto;min-height:0;display:grid;gap:var(--gap);align-items:stretch}
.card{background:#fff;color:var(--ink);box-shadow:0 .15vw .7vw rgba(0,0,0,.08);padding:var(--pad);min-width:0;min-height:0;overflow-wrap:break-word}
.dark{background:var(--dark);color:#fff;padding:var(--pad);min-width:0;min-height:0;overflow-wrap:break-word}
.dark .tag{color:var(--onDark)}
/* option buttons (tabs, filters, role pickers) */
.opt{display:flex;flex-direction:column;gap:.2em;text-align:left;cursor:pointer;background:#fff;color:var(--ink);border:.15vw solid #fff;
 box-shadow:0 .15vw .7vw rgba(0,0,0,.08);padding:min(1.1vw,2vh) min(1.5vw,2.7vh);min-width:0;overflow-wrap:break-word;transition:background .15s,color .15s,border-color .15s}
.opt .t{font-size:calc(1.67*var(--vw));font-weight:700;line-height:1.25;color:inherit}
.opt .s{font-size:calc(1.25*var(--vw));line-height:1.3;color:var(--mut)}
.opt:hover{border-color:var(--tint2)}
.opt[aria-pressed="true"]{background:var(--dark);color:#fff;border-color:var(--dark)}
.opt[aria-pressed="true"] .s{color:var(--tint)}
.seg{display:flex;gap:var(--gap-s);flex-wrap:wrap}
.seg .opt{flex-direction:row;align-items:center;padding:min(.6vw,1.1vh) min(1.3vw,2.3vh)}
.seg .opt .t{font-size:calc(1.4*var(--vw))}
button:focus-visible,input:focus-visible{outline:.25vw solid var(--bar);outline-offset:.2vw}
/* panels switched by initGroup */
.stack{display:grid;min-width:0}
.stack>.panel{grid-area:1/1;visibility:hidden;opacity:0;min-width:0;transition:opacity .2s}
.stack>.panel.active{visibility:visible;opacity:1}
/* toggles (multi-select) */
.tog{flex-direction:row;align-items:center;gap:min(1.1vw,2vh)}
.ck{display:inline-flex;align-items:center;justify-content:center;width:1.9em;height:1.9em;flex:none;border:.15vw solid var(--tint2);color:transparent;font-weight:700;font-size:calc(1.3*var(--vw))}
.tog[aria-pressed="true"] .ck{background:#fff;color:var(--dark);border-color:#fff}
.ghost{align-self:flex-start;cursor:pointer;background:transparent;border:.12vw solid var(--tint2);color:var(--accent);font-weight:700;font-size:calc(1.25*var(--vw));padding:.4em 1em}
/* status pills */
.st{display:inline-flex;align-items:center;justify-content:center;min-width:7.2em;padding:.25em .7em;font-weight:700;font-size:calc(1.25*var(--vw));line-height:1.2;white-space:nowrap}
.st.yes{background:var(--dark);color:#fff}
.st.part{background:var(--tint);color:var(--dark)}
.st.no{background:#fff;color:var(--mut);border:.12vw solid var(--line)}
.st.open{background:#fff;color:var(--accent);border:.12vw dashed var(--bar)}
.st.temp{background:#fff;color:var(--dark);border:.15vw solid var(--dark)}
/* matrix rows */
.row{display:grid;grid-template-columns:minmax(0,9.5em) auto minmax(0,1fr);align-items:center;gap:var(--gap);padding:.55em 0;border-bottom:.1vw solid var(--line)}
.row .area{font-weight:700;font-size:calc(1.46*var(--vw))}
.row .note{color:var(--mut);font-size:calc(1.35*var(--vw))}
/* numbers, progress, KPI */
.num{display:inline-flex;align-items:center;justify-content:center;width:2.2em;height:2.2em;border-radius:50%;background:var(--dark);color:#fff;font-weight:700;font-size:calc(1.46*var(--vw));line-height:1.15;flex:none}
.bar{height:min(1vw,1.8vh);background:var(--tint);position:relative;overflow:hidden}
.bar>i{position:absolute;inset:0 auto 0 0;background:var(--bar);transition:width .3s}
.kpis{display:grid;grid-auto-flow:column;grid-auto-columns:minmax(0,1fr);gap:var(--gap)}
.kpi{background:#fff;box-shadow:0 .15vw .7vw rgba(0,0,0,.08);padding:min(1.4vw,2.5vh) var(--pad);display:flex;flex-direction:column;gap:.25em;min-width:0}
.kpi .v{font-size:calc(3.2*var(--vw));font-weight:700;line-height:1.05;color:var(--dark);font-variant-numeric:tabular-nums}
.kpi .l{font-size:calc(1.35*var(--vw));color:var(--mut)}
.kpi.hi{background:var(--dark)} .kpi.hi .v{color:#fff} .kpi.hi .l{color:var(--tint)}
/* horizontal bar chart rendered by barChart() */
.hbars{display:flex;flex-direction:column;justify-content:space-evenly;gap:var(--gap-s);flex:1;min-height:0}
.hb{display:grid;grid-template-columns:minmax(0,9em) minmax(0,1fr) 5.5em;align-items:center;gap:var(--gap-s)}
.hb .lb{font-weight:700;font-size:calc(1.4*var(--vw));overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hb .tr{height:min(2.2vw,3.9vh);background:var(--bg);position:relative}
.hb .tr>i{position:absolute;inset:0 auto 0 0;background:var(--tint2);transition:width .35s}
.hb.hi .tr>i{background:var(--bar)}
.hb .vl{font-weight:700;font-size:calc(1.4*var(--vw));text-align:right;font-variant-numeric:tabular-nums}
/* stepper rail */
.rail{position:relative;display:grid;grid-auto-flow:column;grid-auto-columns:minmax(0,1fr);gap:var(--gap)}
.rail::before{content:"";position:absolute;left:12.5%;right:12.5%;top:50%;height:.2vw;background:var(--tint2)}
.node{position:relative;display:flex;justify-content:center;background:none;border:0;cursor:pointer;padding:0}
.node .num{background:#fff;color:var(--dark);border:.2vw solid var(--tint2)}
.node[aria-pressed="true"] .num{background:var(--dark);color:#fff;border-color:var(--dark)}
.node .num.ok{background:var(--bar);color:#fff;border-color:var(--bar)}
/* range slider */
.rng{width:100%;accent-color:var(--bar);height:min(2.4vw,4.2vh);cursor:pointer}
/* ---- motion layer: add lv-in / lv-pop / lv-draw / lv-grow classes in markup ---- */
.lv-play .lv-in{animation:lvIn .7s cubic-bezier(.2,.7,.2,1) backwards;animation-delay:calc(var(--i,0) * 110ms + 120ms)}
@keyframes lvIn{from{opacity:0;transform:translateY(22px)}to{opacity:1;transform:none}}
.lv-play .lv-pop{animation:lvPop .9s cubic-bezier(.2,.8,.2,1.2) backwards;animation-delay:calc(var(--i,0) * 110ms + 300ms)}
@keyframes lvPop{from{opacity:0;transform:scale(.6)}to{opacity:1;transform:none}}
.lv-play .lv-draw{animation:lvDraw 1.4s cubic-bezier(.3,.6,.2,1) backwards .35s}
@keyframes lvDraw{from{clip-path:inset(0 100% 0 0)}to{clip-path:inset(0 0 0 0)}}
.lv-play .lv-grow,.lv-play .hb .tr>i,.lv-play .bar>i{transform-origin:left center;animation:lvGrow 1s cubic-bezier(.2,.7,.2,1) backwards;animation-delay:calc(var(--i,0) * 90ms + 250ms)}
@keyframes lvGrow{from{transform:scaleX(0)}to{transform:none}}
.lv-done *:not(.lv-amb){animation:none!important}
/* lv-amb = ambient or click-triggered motion that must survive the safety net; lv-still = picture / reduced motion */
.lv-still .lv-amb,.lv-still.lv-root::before,.lv-still.lv-root::after{animation:none!important}
@media (prefers-reduced-motion:reduce){.lv-play *{animation:none!important}}
@media (prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
@media (max-aspect-ratio:4/3){.main{grid-template-columns:1fr!important}}
@media (forced-colors:active){
 .opt,.card,.dark,.st,.kpi{forced-color-adjust:none;background:Canvas;color:CanvasText;border:2px solid CanvasText}
 .opt[aria-pressed="true"]{background:Highlight;color:HighlightText;border-color:Highlight}
 .opt .s,.mut,.tag,.dark .tag{color:CanvasText}
 button:focus-visible{outline:3px solid Highlight}
}
{css}
</style></head>
<body><div class="viewport lv-root"><main class="page">
'''

_TAIL = r'''<div class="overlay"></div>
</main></div>
<script>
const viewport = document.querySelector(".viewport");
const page = document.querySelector(".page");
function contentHeight() {
  const top = page.getBoundingClientRect().top;
  let bottom = top + page.scrollHeight;
  page.querySelectorAll("*").forEach(el => { if (el.closest(".overlay")) return; bottom = Math.max(bottom, el.getBoundingClientRect().bottom); });
  return bottom - top;
}
function fitPage() {
  const w = viewport.clientWidth, h = viewport.clientHeight;
  page.style.transform = "none"; page.style.width = w + "px";
  if (contentHeight() <= h) { page.style.width = "100%"; viewport.dataset.scale = "1"; return; }
  let low = 0.2, high = 1;
  for (let i = 0; i < 12; i++) { const s = (low + high) / 2; page.style.width = (w / s) + "px"; if (contentHeight() * s <= h) low = s; else high = s; }
  page.style.width = (w / low) + "px"; page.style.transform = "scale(" + low + ")"; viewport.dataset.scale = low.toFixed(2);
}
var fitFrame;
function scheduleFit() { cancelAnimationFrame(fitFrame); fitFrame = requestAnimationFrame(fitPage); }
new ResizeObserver(scheduleFit).observe(viewport);
addEventListener("load", scheduleFit); addEventListener("resize", scheduleFit);
document.fonts?.ready.then(scheduleFit);
/* single choice: buttons [data-g=name][data-i], panels [data-p=name][data-i]; hooks[name](i) */
const selHooks = {};
function initGroup(name, start) {
  const btns = [...document.querySelectorAll('[data-g="' + name + '"]')];
  const panels = [...document.querySelectorAll('[data-p="' + name + '"]')];
  function set(i) {
    btns.forEach(b => b.setAttribute("aria-pressed", String(Number(b.dataset.i) === i)));
    panels.forEach(p => p.classList.toggle("active", Number(p.dataset.i) === i));
    if (selHooks[name]) selHooks[name](i);
    scheduleFit();
  }
  btns.forEach(b => b.addEventListener("click", () => set(Number(b.dataset.i))));
  set(start || 0);
  return set;
}
/* multi select: elements matching selector toggle aria-pressed; onChange(boolArray) */
function initToggles(selector, onChange) {
  const els = [...document.querySelectorAll(selector)];
  const state = () => els.map(e => e.getAttribute("aria-pressed") === "true");
  els.forEach(e => e.addEventListener("click", () => { e.setAttribute("aria-pressed", String(e.getAttribute("aria-pressed") !== "true")); onChange(state()); scheduleFit(); }));
  onChange(state());
  return { els, state, setAll(v) { els.forEach(e => e.setAttribute("aria-pressed", String(v))); onChange(state()); scheduleFit(); } };
}
/* number format; locale fixed at build time (attributes on <html> do not survive in PowerPoint) */
const LV_LANG = "{lang}";
function fmt(n, opt) { return new Intl.NumberFormat(LV_LANG, opt || { maximumFractionDigits: 0 }).format(n); }
/* horizontal bars: data [{label, value, hi?}], opts {max, unit, decimals} -> renders into el */
function barChart(el, data, opts) {
  opts = opts || {}; const max = opts.max || Math.max(...data.map(d => d.value), 1);
  el.innerHTML = data.map(d => '<div class="hb' + (d.hi ? ' hi' : '') + '"><span class="lb">' + d.label + '</span><span class="tr"><i style="width:' + (100 * d.value / max) + '%"></i></span><span class="vl">' + fmt(d.value, { maximumFractionDigits: opts.decimals || 0 }) + (opts.unit || '') + '</span></div>').join("");
  scheduleFit();
}
/* ---- motion layer ---- */
/* window.LV_SNAPSHOT is set only while the fallback picture is rendered: no motion, final values. */
const LV_SNAP = !!window.LV_SNAPSHOT;
const LV_REDUCE = !!(window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches);
const LV_STILL = LV_SNAP || LV_REDUCE;  /* skins: draw final frames, no loops */
/* stagger: give each matching element --i = its position among siblings with the same class */
function lvStagger(selector) {
  const seen = new Map();
  document.querySelectorAll(selector).forEach(el => { const k = el.parentNode; const n = seen.get(k) || 0; if (!el.style.getPropertyValue("--i")) el.style.setProperty("--i", n); seen.set(k, n + 1); });
}
/* count-up: <span data-count="90211" data-suffix="%" data-decimals="0">90,211</span> (markup holds the final text) */
function lvCount(el) {
  const target = Number(el.dataset.count), dec = Number(el.dataset.decimals || 0), pre = el.dataset.prefix || "", suf = el.dataset.suffix || "";
  const out = v => pre + fmt(v, { minimumFractionDigits: dec, maximumFractionDigits: dec }) + suf;
  if (LV_SNAP || LV_REDUCE) { el.textContent = out(target); return; }
  const t0 = performance.now(), dur = Number(el.dataset.duration || 1200);
  (function step() { const p = Math.min(1, (performance.now() - t0) / dur); el.textContent = out(target * (1 - Math.pow(1 - p, 3))); if (p < 1) setTimeout(step, 16); })();
}
function lvPlay() {
  if (LV_SNAP || LV_REDUCE) { document.querySelector(".lv-root").classList.add("lv-still"); document.querySelectorAll("[data-count]").forEach(lvCount); return; }
  const r = document.querySelector(".lv-root"); r.classList.remove("lv-play", "lv-done"); void r.offsetWidth; r.classList.add("lv-play");
  if (lvPlay.n = (lvPlay.n || 0) + 1, lvPlay.n > 1) dispatchEvent(new Event("lv:play"));  /* replays: custom elements re-animate */
  document.querySelectorAll("[data-count]").forEach(lvCount);
  clearTimeout(lvPlay.t); lvPlay.t = setTimeout(() => r.classList.add("lv-done"), Number(document.querySelector(".lv-root").dataset.motionMs || 4500));
}
/* plays when the block first gets a real size, replays when the frame size jumps (e.g. entering the slide show) */
let lvLastW = 0;
function lvMaybePlay() { const w = innerWidth; if (w < 40) return; if (!lvLastW || Math.abs(w - lvLastW) / lvLastW > 0.25) { lvLastW = w; lvPlay(); } }
addEventListener("resize", lvMaybePlay);
{js}
lvStagger('.lv-in'); lvStagger('.lv-pop'); lvStagger('.lv-grow'); lvMaybePlay();
</script></body></html>'''


def components_js():
    """The Live Slides custom elements (lv-ring, lv-spark, lv-flip, lv-reveal) as inline script text."""
    import os
    return open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "lv_components.js"), encoding="utf8").read()


def page(title, body, css="", js="", theme="microsoft", lang="de", components=False):
    """components=True inlines the custom elements from lv_components.js before the slide's own js."""
    if components:
        js = "window.LV_LANG_JS = LV_LANG;\n" + components_js() + "\n" + js
    t = THEMES[theme] if isinstance(theme, str) else theme
    head = _HEAD.replace("{lang}", lang).replace("{title}", title).replace("{css}", css)
    for k, v in t.items():
        head = head.replace("{" + k + "}", v)
    return head + body + _TAIL.replace("{lang}", lang).replace("{js}", js)
