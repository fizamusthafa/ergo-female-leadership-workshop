#!/usr/bin/env python3
"""Live Slides builder: HTML slides -> PowerPoint with embedded content blocks.

usage: python build_live_deck.py spec.json "<Deck Title>.pptx" [--check-only]

spec.json = {"title": "Deck title", "slides": [{"html": "s1.html", "title": "Slide title", "alt": "What the slide shows", "snapshot_js": "optional JS run only for the picture"}]}

Per slide: (1) check the HTML is self-contained and loads without script errors,
(2) render the fallback picture (1920x1080) with headless Chromium, with window.LV_SNAPSHOT=true,
(3) write a slide holding PowerPoint's own content-block web add-in (same reference PowerPoint
Copilot uses: id fa000000210, store en-US, storeType sdxcatalog) whose property contentBlockHtml
holds the HTML as a JSON string, with the picture as mc:Fallback + snapshot, and an off-slide title.
"""
import glob, json, os, random, re, shutil, subprocess, sys, tempfile, uuid
from lxml import etree

WE_NS = "http://schemas.microsoft.com/office/webextensions/webextension/2010/11"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
RT_WEBEXT = "http://schemas.microsoft.com/office/2011/relationships/webextension"
CT_WEBEXT = "application/vnd.ms-office.webextension+xml"
W, H = 1920, 1080

def chrome():
    c = os.environ.get("CHROME") or next(iter(sorted(glob.glob("/opt/docgen-browsers/*/chrome-linux64/chrome"))), None) \
        or shutil.which("chromium") or shutil.which("google-chrome") or shutil.which("chromium-browser")
    return c

def run_chrome(args, timeout=60):
    return subprocess.run([chrome(), "--headless=new", "--no-sandbox", "--disable-gpu", "--hide-scrollbars",
                           "--force-device-scale-factor=1", "--window-size=1920,1167"] + args,
                          capture_output=True, text=True, timeout=timeout)

EXTERNAL = re.compile(r'(?:src|href)\s*=\s*["\'](?:https?:)?//|@import|url\(\s*["\']?(?:https?:)?//|\bfetch\s*\(|XMLHttpRequest|<iframe', re.I)

def as_hosted(html):
    """PowerPoint's content-block host does not keep attributes on <html> (seen: class lost in the
    slide show, page fell back to its non-presentation layout). Treat <body> the same way."""
    html = re.sub(r"<html[^>]*>", "<html>", html, count=1, flags=re.I)
    return re.sub(r"<body[^>]*>", "<body>", html, count=1, flags=re.I)

ROOT_DEP = re.compile(r"(?:^|[\s,}])(?:html|body)(?:\.[\w-]+|\[[^\]]+\]|#[\w-]+)", re.M)

def check(html_path):
    html = open(html_path, encoding="utf8").read()
    issues = [f"external or network reference: {m.group(0)[:40]}" for m in EXTERNAL.finditer(html)]
    styles = " ".join(re.findall(r"<style[^>]*>(.*?)</style>", html, flags=re.S | re.I))
    dep = sorted(set(m.group(0).strip(" ,}\n\t") for m in ROOT_DEP.finditer(styles)))
    if dep: issues.append("styles depend on attributes of <html>/<body>, which PowerPoint drops: " + ", ".join(dep[:5]) + " - move them to a wrapper div")
    html = as_hosted(html)
    if len(html.encode()) > 250_000: issues.append(f"large block ({len(html.encode())//1024} KB) - keep under ~150 KB")
    probe = html.replace("<head>", "<head><script>window.__e=[];addEventListener('error',function(e){__e.push(e.message)});</script>", 1)
    probe = probe.replace("</body>", "<script>setTimeout(function(){document.body.setAttribute('data-lv-probe',JSON.stringify({e:__e,scale:(document.querySelector('.viewport')||document.body).dataset.scale||'1'}))},600)</script></body>")
    with tempfile.NamedTemporaryFile("w", suffix=".html", delete=False, encoding="utf8", dir=os.path.dirname(os.path.abspath(html_path))) as f:
        f.write(probe); tmp = f.name
    try:
        out = None
        for _ in range(2):  # one retry: headless can stall on a busy page
            try: out = run_chrome(["--virtual-time-budget=1500", "--dump-dom", "file://" + tmp]).stdout; break
            except subprocess.TimeoutExpired: pass
        if out is None:
            issues.append("page kept the browser busy for 60 s twice - lighten continuous loops (canvas, timers)"); return issues
        m = re.search(r'data-lv-probe="([^"]*)"', out)
        if not m: issues.append("could not read the page state (script blocked or crashed)")
        else:
            d = json.loads(m.group(1).replace("&quot;", '"'))
            issues += [f"script error: {e}" for e in d["e"]]
            if float(d["scale"]) < 0.97: issues.append(f"content does not fit 1920x1080, auto-scaled to {d['scale']} - trim or tighten it")
    finally:
        os.unlink(tmp)
    return issues

def snapshot(html_path, png_path, extra_js=""):
    from PIL import Image
    html = as_hosted(open(html_path, encoding="utf8").read())
    snap = html.replace("<head>", "<head><script>window.LV_SNAPSHOT=true;</script>", 1)
    if extra_js: snap = snap.replace("</body>", f"<script>addEventListener('load',function(){{{extra_js}}});</script></body>")
    with tempfile.NamedTemporaryFile("w", suffix=".html", delete=False, encoding="utf8", dir=os.path.dirname(os.path.abspath(html_path))) as f:
        f.write(snap); tmp = f.name
    raw = png_path + ".raw.png"
    try:
        for _ in range(2):
            try: run_chrome(["--virtual-time-budget=3000", f"--screenshot={raw}", "file://" + tmp]); break
            except subprocess.TimeoutExpired: pass
        Image.open(raw).convert("RGB").crop((0, 0, W, H)).save(png_path, optimize=True)  # headless reserves 87px: render 1167 tall, keep 1080
    finally:
        os.unlink(tmp)
        if os.path.exists(raw): os.unlink(raw)

def webext_xml(html, img_rid):
    we = etree.Element(f"{{{WE_NS}}}webextension", nsmap={"we": WE_NS}, id="{" + str(uuid.uuid4()).upper() + "}")
    etree.SubElement(we, f"{{{WE_NS}}}reference", id="fa000000210", version="1.0.0.0", store="en-US", storeType="sdxcatalog")
    etree.SubElement(we, f"{{{WE_NS}}}alternateReferences")
    props = etree.SubElement(we, f"{{{WE_NS}}}properties")
    etree.SubElement(props, f"{{{WE_NS}}}property", name="contentBlockHtml", value=json.dumps(html))
    etree.SubElement(we, f"{{{WE_NS}}}bindings")
    snap = etree.SubElement(we, f"{{{WE_NS}}}snapshot", nsmap={"r": R_NS}); snap.set(f"{{{R_NS}}}embed", img_rid)
    return etree.tostring(we, xml_declaration=True, encoding="UTF-8", standalone=True)

def frame_xml(shape_id, descr, we_rid, img_rid):
    cid = "{" + str(uuid.uuid4()).upper() + "}"
    d = descr.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;")
    cnv = (f'<p:cNvPr id="{shape_id}" name="Copilot Content Block" descr="{d}"><a:extLst><a:ext uri="{{FF2B5EF4-FFF2-40B4-BE49-F238E27FC236}}">'
           f'<a16:creationId xmlns:a16="http://schemas.microsoft.com/office/drawing/2014/main" id="{cid}"/></a:ext></a:extLst></p:cNvPr>')
    full = '<a:off x="0" y="0"/><a:ext cx="12192000" cy="6858000"/>'
    return (f'<mc:AlternateContent xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" '
            f'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="{R_NS}"><mc:Choice xmlns:we="{WE_NS}" xmlns:pca="http://schemas.microsoft.com/office/powerpoint/2013/contentapp" Requires="we pca">'
            f'<p:graphicFrame><p:nvGraphicFramePr>{cnv}<p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1" noChangeAspect="1" noMove="1" noResize="1"/></p:cNvGraphicFramePr>'
            f'<p:nvPr><p:extLst><p:ext uri="{{D42A27DB-BD31-4B8C-83A1-F6EECF244321}}"><p14:modId xmlns:p14="http://schemas.microsoft.com/office/powerpoint/2010/main" val="{random.randint(10**8, 4*10**9)}"/></p:ext></p:extLst></p:nvPr></p:nvGraphicFramePr>'
            f'<p:xfrm>{full}</p:xfrm><a:graphic><a:graphicData uri="{WE_NS}"><we:webextensionref xmlns:we="{WE_NS}" r:id="{we_rid}"/></a:graphicData></a:graphic></p:graphicFrame></mc:Choice>'
            f'<mc:Fallback><p:pic><p:nvPicPr>{cnv}<p:cNvPicPr><a:picLocks noGrp="1" noRot="1" noChangeAspect="1" noMove="1" noResize="1" noEditPoints="1" noAdjustHandles="1" noChangeArrowheads="1" noChangeShapeType="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>'
            f'<p:blipFill><a:blip r:embed="{img_rid}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm>{full}</a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic></mc:Fallback></mc:AlternateContent>')

def build(spec, out):
    from pptx import Presentation
    from pptx.opc.package import Part
    from pptx.opc.packuri import PackURI
    from pptx.opc.constants import RELATIONSHIP_TYPE as RT
    prs = Presentation(); prs.slide_width, prs.slide_height = 12192000, 6858000
    prs.core_properties.title = spec.get("title", "")
    layout = prs.slide_layouts[5]  # Title Only
    for i, s in enumerate(spec["slides"], 1):
        slide = prs.slides.add_slide(layout)
        t = slide.shapes.title; t.text = s["title"]
        t.left, t.top, t.width, t.height = 0, -1100000, 12192000, 1100000  # off-slide title, as PowerPoint does
        png = os.path.splitext(s["html"])[0] + ".png"
        img_part, img_rid = slide.part.get_or_add_image_part(png)
        we = Part(PackURI(f"/ppt/webextensions/webextension{i}.xml"), CT_WEBEXT, prs.part.package, b"")
        we._blob = webext_xml(open(s["html"], encoding="utf8").read(), we.relate_to(img_part, RT.IMAGE))
        we_rid = slide.part.relate_to(we, RT_WEBEXT)
        slide.shapes._spTree.append(etree.fromstring(frame_xml(t.shape_id + 1, s.get("alt", s["title"]), we_rid, img_rid)))
    prs.save(out)

if __name__ == "__main__":
    spec_path, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
    os.chdir(os.path.dirname(spec_path))
    spec = json.load(open(spec_path, encoding="utf8"))
    if not chrome(): sys.exit("no headless Chromium found - set CHROME=/path/to/chrome")
    bad = False
    for s in spec["slides"]:
        issues = check(s["html"])
        print(f"{s['html']}: " + ("ok" if not issues else "; ".join(issues)))
        bad |= any(not i.startswith("content does not fit") for i in issues)
    if "--check-only" in sys.argv: sys.exit(1 if bad else 0)
    if bad: sys.exit("fix the issues above first")
    for s in spec["slides"]:
        snapshot(s["html"], os.path.splitext(s["html"])[0] + ".png", s.get("snapshot_js", ""))
    build(spec, out)
    print("saved", out)
