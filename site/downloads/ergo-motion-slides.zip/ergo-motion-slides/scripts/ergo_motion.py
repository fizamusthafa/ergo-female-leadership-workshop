"""ERGO Motion look for Live Slides: investor-deck layout in ERGO brand (Arial, Logo Red titles,
red tiles and bands, grey side panels, dark-red accents), calm corporate motion, ERGO logo from assets/.

Use: page(title, body, css=ergo_motion.CSS, js=ergo_motion.JS, theme=ergo_motion.THEME, components=True)
Every content slide = header(...) + body(...) + [side_panel(...)] + footer(...). Helpers return HTML.
Layout is a flex column: header, body (fills the free height), footer (in flow, never overlaps)."""
import base64, html as _html, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "..", "assets")
LOGO = json.load(open(os.path.join(ASSETS, "logo.json"), encoding="utf8"))
ERGO_ICONS = json.load(open(os.path.join(ASSETS, "icons.json"), encoding="utf8"))["icons"]

RED, DARK, WARM, INK, MUTED = "#BF1528", "#7A0E1C", "#615E5C", "#262626", "#4D4D4D"
PANEL, GRID, ON_RED = "#EFEDED", "#D9D4D4", "#F5DCDF"
SERIES = [RED, DARK, "#DF8A93", WARM, "#EBB9BE", "#8C8C8C"]
LOGO_COLORS = {"red": RED, "white": "#FFFFFF"}


def esc(t): return _html.escape(str(t), quote=False)


# ---------- logo + icons ----------
def logo(variant="red", width_px=150, cls="lv-logo"):
    """ERGO wordmark (red on white/grey, white on red) built from assets/logo.json. width on the 1920 px slide."""
    if variant not in LOGO_COLORS:
        raise ValueError("logo variant must be 'red' or 'white'")
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{LOGO["viewBox"]}" fill="{LOGO_COLORS[variant]}">'
           + "".join(f'<path d="{d}"/>' for d in LOGO["paths"]) + "</svg>")
    uri = "data:image/svg+xml;base64," + base64.b64encode(svg.encode()).decode()
    return f'<img class="{cls}" src="{uri}" alt="ERGO" style="width:calc({width_px / 19.2:.3f}*var(--vw));height:auto">'


def _mono(p):
    return ('<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" '
            f'stroke-linejoin="round" aria-hidden="true">{p}</svg>')


# small generic monoline set for meanings the ERGO set does not cover
MONO = {
    "eye": _mono('<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>'),
    "ear": _mono('<path d="M7 9a5 5 0 0 1 10 0c0 3-2.5 4-3.5 6s-1 4-3.5 4A3 3 0 0 1 7 16"/><path d="M10 9a2 2 0 0 1 4 0c0 1.2-1 1.6-1.6 2.4"/>'),
    "chat": _mono('<path d="M4 5h16v11H9l-5 4z"/><path d="M8 10h8M8 13h5"/>'),
    "chart": _mono('<path d="M4 20V4M4 20h16"/><path d="M8 16v-4M12 16V9M16 16v-6"/>'),
    "clock": _mono('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
    "heart": _mono('<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>'),
    "target": _mono('<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/>'),
    "gear": _mono('<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8"/>'),
    "spark": _mono('<path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/>'),
    "lock": _mono('<rect x="5" y="11" width="14" height="9" rx="1.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>'),
}
ICON_NAMES = sorted(ERGO_ICONS) + sorted(MONO)


def icon(name):
    """ERGO icon (filled line art) or generic monoline icon. Pick one that matches the meaning;
    if none fits use None in pillars() and get a numbered disc instead."""
    if name in ERGO_ICONS:
        ic = ERGO_ICONS[name]
        return (f'<svg viewBox="{ic["viewBox"]}" fill="currentColor" aria-hidden="true">'
                + "".join(f'<path d="{d}"/>' for d in ic["paths"]) + "</svg>")
    if name in MONO:
        return MONO[name]
    raise ValueError(f"unknown icon {name!r}; choose from {ICON_NAMES}")


# ---------- frame ----------
def header(title, sub="", kicker=""):
    """Red message title top-left (regular, 1-2 lines), optional red subhead and grey kicker
    (e.g. 'Appendix'), red ERGO logo top-right."""
    k = f'<p class="egkick">{esc(kicker)}</p>' if kicker else ""
    s = f'<p class="egsub">{esc(sub)}</p>' if sub else ""
    return f'<header class="eghead">{"<div>" + k + f"<h1>{esc(title)}</h1>" + s + "</div>"}{logo("red", 150)}</header>'


def body(*parts, align="top"):
    """Content area between header and footer; fills the free height. align: 'top' | 'center' |
    'spread' (first part at top, last part at the bottom - e.g. content + takeaway band)."""
    return f'<div class="egbody al-{align}">{"".join(parts)}</div>'


def footer(page_no, label="", source=""):
    """Bottom line in flow: source left, 'Event - Title' + bold page number right."""
    return (f'<div class="egfoot"><span class="srcl">{esc(source)}</span>'
            f'<span class="fr">{esc(label)}<b>{page_no}</b></span></div>')


# ---------- full-slide layouts ----------
def cover(title, subline, date="", speakers=(), photo_uri=""):
    """Cover / closer. Red shape field (or a user photo as data URI, <100 KB JPEG, with a dark lower-left
    shade), bold white title, subline, date, speakers, white ERGO logo bottom-right."""
    sp = "".join(f'<li><b>{esc(n)}</b>{(" · " + esc(r)) if r else ""}</li>' for n, r in speakers)
    bg = (f'<div class="egphoto" style="background-image:url({photo_uri})"></div><i class="shade"></i>' if photo_uri
          else '<div class="egfield lv-amb" aria-hidden="true"><i class="f1"></i><i class="f2"></i><i class="f3"></i></div>')
    return f'''<section class="egcover">{bg}
 <div class="ctext"><h1 class="lv-in">{esc(title)}</h1><p class="cline lv-in">{esc(subline)}</p>
  {f'<p class="cdate lv-in">{esc(date)}</p>' if date else ''}{f'<ul class="cspk lv-in">{sp}</ul>' if sp else ''}</div>
 <div class="clogo">{logo("white", 230)}</div></section>'''


def divider(title, sub="", label="", number=None):
    """Section / appendix divider: red block left with big white title, large grey numeral right."""
    num = f'<span class="dnum lv-in">{number:02d}</span>' if isinstance(number, int) else ""
    return f'''<section class="egdiv"><div class="dl"><p class="dlab lv-in">{esc(label)}</p>
 <h1 class="lv-in">{esc(title)}</h1>{f'<p class="dsub lv-in">{esc(sub)}</p>' if sub else ''}</div>
 <div class="dr">{num}<div class="dlogo">{logo("red", 170)}</div></div></section>'''


# ---------- components ----------
def agenda(items, active=0, detail=()):
    """items = [(title, subtitle)]; active = big red tile with 2-digit numeral and optional detail
    bullets; others = shorter grey tiles. Fills the body; all tiles bottom-aligned."""
    t = []
    for i, (a, b) in enumerate(items):
        on = i == active
        d = ("<ul class='sq'>" + "".join(f"<li>{esc(x)}</li>" for x in detail) + "</ul>") if on and detail else ""
        t.append(f'<div class="agt lv-in{" on" if on else ""}"><p class="at">{esc(a)}</p><p class="as">{esc(b)}</p>{d}'
                 f'<span class="an">{i + 1:02d}</span></div>')
    cols = "1.8fr " + " ".join(["1fr"] * (len(items) - 1))
    return f'<div class="egagenda" style="grid-template-columns:{cols}">{"".join(t)}</div>'


def side_panel(head, sub="", bullets=(), extra=""):
    """Grey panel bleeding off the right edge: bold red head, red subhead, square bullets."""
    li = "".join(f'<li class="lv-in">{esc(b)}</li>' for b in bullets)
    return (f'<aside class="egside"><h2>{esc(head)}</h2>{f"<p class=sb>{esc(sub)}</p>" if sub else ""}'
            f'<ul class="sq">{li}</ul>{extra}</aside>')


def takeaway(text):
    """Full-width red band, one bold white sentence. Put it last in body(..., align='spread')."""
    return f'<div class="egband lv-in"><p>{esc(text)}</p></div>'


def kpi_tiles(tiles):
    """tiles = [(label, number, suffix, decimals, note)] -> red tiles, values count up."""
    out = []
    for lab, v, suf, dec, ex in tiles:
        shown = f"{v:,.{dec}f}{suf}"
        out.append(f'<div class="egkpi lv-in"><p class="kl">{esc(lab)}</p><p class="ke">{esc(ex)}</p>'
                   f'<p class="kv" data-count="{v}" data-decimals="{dec}" data-suffix="{esc(suf)}">{shown}</p></div>')
    return f'<div class="egkpis">{"".join(out)}</div>'


def pillars(items, fill=True):
    """items = [(icon_name_or_None, heading, body_text_or_list)] -> grey columns. None = numbered disc.
    fill=True stretches them to the free height (use when they are the main content)."""
    out = []
    for i, (ic, h, b) in enumerate(items):
        mark = f'<span class="mi">{icon(ic)}</span>' if ic else f'<span class="nd">{i + 1}</span>'
        txt = ("<ul class='sq'>" + "".join(f"<li>{esc(x)}</li>" for x in b) + "</ul>") if isinstance(b, (list, tuple)) else f"<p>{esc(b)}</p>"
        out.append(f'<div class="pil lv-in">{mark}<h3>{esc(h)}</h3>{txt}</div>')
    return f'<div class="egpillars{" fill" if fill else ""}">{"".join(out)}</div>'


def rings(items, hero=None):
    """items = [(value, max, label, suffix, decimals)]; `hero` index = larger dark-red ring (one per slide)."""
    out = []
    for i, (v, mx, lab, suf, dec) in enumerate(items):
        h = i == hero
        out.append(f'<lv-ring class="lv-in{" hero" if h else ""}" value="{v}" max="{mx}" label="{esc(lab)}" suffix="{esc(suf)}" '
                   f'decimals="{dec}" size="{".62" if h else ".46"}" delay="{500 + 150 * i}"></lv-ring>')
    return f'<div class="egrings">{"".join(out)}</div>'


def bar_chart(labels, values, title="", unit="", cagr="", decimals=0, threshold=None, accent_ends=False, colors=None):
    """Vertical bars that grow, values on top. cagr='5.8% CAGR' adds bracket + red pill (top room is
    reserved only then). threshold=(value, 'label') = dotted dark-red line; label sits on the side
    whose end bar is below the line. accent_ends = first/last value in dark red."""
    n = len(values); mx = max(list(values) + ([threshold[0]] if threshold else [])) or 1
    H = 72.0 if cagr else 88.0
    hs = [H * v / mx for v in values]
    cols, labs = [], []
    for i, (l, v, h) in enumerate(zip(labels, values, hs)):
        c = (colors or [RED] * n)[i]
        acc = " acc" if accent_ends and i in (0, n - 1) else ""
        cols.append(f'<div class="bc"><span class="bv{acc}" style="bottom:{h:.1f}%">{v:,.{decimals}f}</span>'
                    f'<i class="bar lv-grow" style="height:{h:.1f}%;background:{c};--i:{i}"></i></div>')
        labs.append(f'<span>{esc(l)}</span>')
    br = ""
    if cagr and n > 1:
        top = H + 17
        lp, rp = 50 / n, 100 - 50 / n
        br = (f'<div class="brk lv-draw" style="left:{lp:.2f}%;right:{100 - rp:.2f}%;bottom:{top:.1f}%"></div>'
              f'<i class="leg" style="left:{lp:.2f}%;bottom:{hs[0] + 9:.1f}%;height:{top - hs[0] - 9:.1f}%"></i>'
              f'<i class="leg" style="left:{rp:.2f}%;bottom:{hs[-1] + 9:.1f}%;height:{top - hs[-1] - 9:.1f}%"></i>'
              f'<span class="pill" style="left:50%;bottom:{top:.1f}%">{esc(cagr)}</span>')
    th = ""
    if threshold:
        y = H * threshold[0] / mx
        side = "right:0" if values[-1] < threshold[0] else ("left:0" if values[0] < threshold[0] else "right:0;bottom:auto!important;top:-1.6em")
        th = (f'<i class="thr lv-draw" style="bottom:{y:.1f}%"></i>'
              f'<span class="thl" style="bottom:{y:.1f}%;{side}">{esc(threshold[1])}</span>')
    ttl = f'<p class="ct">{esc(title)}{f" <span>{esc(unit)}</span>" if unit else ""}</p>' if title else ""
    grid = "".join(f'<i class="gl" style="bottom:{H * k / 4:.1f}%"></i>' for k in range(0, 5))
    return (f'<figure class="egbars lv-in">{ttl}<div class="pa">{grid}<div class="cols">{"".join(cols)}</div>{th}{br}</div>'
            f'<div class="bls">{"".join(labs)}</div></figure>')


def hbars(items, unit="", decimals=0, highlight=None):
    """Horizontal bars: items = [(label, value)]; `highlight` index red, others light red."""
    mx = max(v for _, v in items) or 1
    rows = "".join(
        f'<div class="hr lv-in"><span class="hl">{esc(l)}</span><span class="ht"><i class="lv-grow" style="width:{88 * v / mx:.1f}%;'
        f'background:{RED if highlight in (None, i) else "#EBB9BE"};--i:{i}"></i><b>{v:,.{decimals}f}{esc(unit)}</b></span></div>'
        for i, (l, v) in enumerate(items))
    return f'<div class="eghbars">{rows}</div>'


def donut(parts, centre="", centre_sub=""):
    """parts = [(label, value)] -> thick donut, white gaps, legend with shares, bold centre label."""
    tot = sum(v for _, v in parts) or 1; start = 0; segs = []; leg = []
    for i, (lab, v) in enumerate(parts):
        p = 100 * v / tot; c = SERIES[i % len(SERIES)]
        segs.append(f'<circle class="dseg" style="--d:{max(p - .6, .1):.2f};--o:{-start:.2f};--i:{i}" stroke="{c}" cx="60" cy="60" r="46" pathLength="100"/>')
        leg.append(f'<li><i style="background:{c}"></i><span>{esc(lab)}</span><b>{p:.0f}%</b></li>')
        start += p
    return (f'<figure class="egdonut lv-in"><div class="dw"><svg viewBox="0 0 120 120" aria-hidden="true">{"".join(segs)}</svg>'
            f'<div class="dc"><b>{esc(centre)}</b><span>{esc(centre_sub)}</span></div></div><ul class="dlg">{"".join(leg)}</ul></figure>')


def timeline(items, now=None):
    """items = [(when, what)] -> 'when' above the rail (bold red), discs on the rail, 'what' below.
    The rail draws left to right; index `now` is a filled disc. Centred in the free height."""
    li = "".join(f'<li class="lv-pop{" now" if i == now else ""}"><b>{esc(w)}</b><i class="dot"></i><span>{esc(x)}</span></li>'
                 for i, (w, x) in enumerate(items))
    return f'<div class="egtlwrap"><ol class="egtl"><i class="line lv-draw" aria-hidden="true"></i>{li}</ol></div>'


THEME = dict(ink=INK, mut=MUTED, dark=DARK, accent=RED, bar=RED, tint=PANEL, tint2=GRID, onDark=ON_RED,
             line=GRID, bg="#FFFFFF", font='Arial, "Liberation Sans", Helvetica, sans-serif')

CSS = r'''
.viewport{background:#FFFFFF}
.page{--safe-t:4.2vh;--safe-l:3.75vw;--safe-r:3.75vw;--safe-b:2.4vh;z-index:1;font-family:Arial,"Liberation Sans",Helvetica,sans-serif}
h1,h2,h3{color:#BF1528}
.lv-logo{display:block;flex:none}
/* frame: header, body (fills), footer (in flow) */
.eghead{display:flex;justify-content:space-between;align-items:flex-start;gap:calc(3*var(--vw));flex:none}
.eghead h1{font-weight:400;font-size:calc(2.5*var(--vw));line-height:1.18;max-width:28em;color:#BF1528}
.egkick{font-size:calc(.9*var(--vw));font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#4D4D4D;margin-bottom:.4em}
.egsub{font-size:calc(1.45*var(--vw));color:#BF1528;margin-top:.35em}
.eghead .lv-logo{margin-top:calc(.35*var(--vw))}
.egbody{flex:1;min-height:0;display:flex;flex-direction:column;gap:var(--gap);padding-top:1vh}
.egbody.al-center{justify-content:center}
.egbody.al-spread{justify-content:space-between}
.egfoot{flex:none;display:flex;justify-content:space-between;align-items:flex-end;gap:calc(2*var(--vw));font-size:calc(.85*var(--vw));color:#4D4D4D;line-height:1.3;position:relative;z-index:3}
.egfoot .srcl{max-width:58%}
.egfoot .fr{white-space:nowrap}.egfoot .fr b{margin-left:1.6em;color:#262626}
/* side panel */
.page:has(.egside) .egbody{margin-right:30vw}
.page:has(.egside) .egfoot .srcl{max-width:calc(100% - 32vw)}
.egside{position:absolute;right:0;top:14.5vh;bottom:6.5vh;width:27vw;background:#EFEDED;padding:calc(2*var(--vw)) calc(2.4*var(--vw)) calc(2*var(--vw)) calc(2*var(--vw));display:flex;flex-direction:column;gap:.8em;z-index:1}
.egside h2{margin:0;font-size:calc(1.85*var(--vw));font-weight:700}
.egside .sb{font-size:calc(1.4*var(--vw));color:#BF1528;margin-bottom:.3em}
/* square bullets */
ul.sq{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:.6em}
ul.sq li{position:relative;padding-left:1.15em;font-size:calc(1.4*var(--vw));line-height:1.35;color:#262626}
ul.sq li::before{content:"";position:absolute;left:0;top:.5em;width:.4em;height:.4em;background:#BF1528}
/* cover */
.page:has(.egcover),.page:has(.egdiv){padding:0}
.egcover{position:absolute;inset:0;background:#BF1528;color:#fff;overflow:hidden}
.egfield,.egphoto{position:absolute;inset:0}.egphoto{background-size:cover;background-position:center}
.egcover .shade{position:absolute;inset:0;background:linear-gradient(20deg,rgba(20,20,20,.75) 0%,rgba(20,20,20,.35) 45%,rgba(20,20,20,0) 70%)}
.egfield i{position:absolute;display:block}
.egfield .f1{inset:0;background:#BF1528}
.egfield .f2{right:0;top:0;width:58%;height:100%;background:#7A0E1C;opacity:.32;clip-path:polygon(100% 0,100% 100%,0 100%)}
.egfield .f3{right:0;top:0;width:30%;height:100%;background:#7A0E1C;opacity:.3;clip-path:polygon(100% 0,100% 100%,0 100%)}
.lv-play .egfield .f3{animation:egDrift 24s ease-in-out infinite alternate}
@keyframes egDrift{to{transform:translateX(-3%)}}
.egfield::after{content:"";position:absolute;left:0;bottom:0;width:60%;height:40%;background:#7A0E1C;opacity:.22}
.ctext{position:absolute;left:5.2vw;right:32vw;bottom:15vh;z-index:2}
.ctext h1{color:#fff;font-weight:700;font-size:calc(4*var(--vw));line-height:1.1}
.cline{font-size:calc(1.6*var(--vw));margin-top:.8em;color:#fff}
.cdate{font-size:calc(1.35*var(--vw));margin-top:.35em;color:#F5DCDF}
.cspk{list-style:none;margin:1.2em 0 0;padding:0;font-size:calc(1.3*var(--vw));line-height:1.6;color:#F5DCDF}.cspk b{color:#fff}
.clogo{position:absolute;right:4.5vw;bottom:7vh;z-index:2}
/* divider */
.egdiv{position:absolute;inset:0;display:grid;grid-template-columns:57% 43%;background:#fff}
.egdiv .dl{background:#BF1528;padding:16vh 5.2vw 0;display:flex;flex-direction:column;gap:1.2vh;position:relative}
.egdiv .dl::after{content:"";position:absolute;left:0;right:0;bottom:0;height:30%;background:#7A0E1C;opacity:.3}
.egdiv .dlab{font-size:calc(1.1*var(--vw));font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#F5DCDF}
.egdiv h1{color:#fff;font-size:calc(4.2*var(--vw));font-weight:700;line-height:1.08}
.egdiv .dsub{font-size:calc(1.6*var(--vw));color:#F5DCDF;max-width:80%}
.egdiv .dr{position:relative}
.egdiv .dnum{position:absolute;right:4.5vw;bottom:16vh;font-size:calc(15*var(--vw));line-height:.8;font-weight:700;color:#EFEDED}
.egdiv .dlogo{position:absolute;right:4.5vw;bottom:7vh}
/* agenda: fills the body */
.egagenda{flex:1;min-height:0;display:grid;gap:var(--gap);align-items:end;margin-bottom:1vh}
.agt{position:relative;background:#EFEDED;color:#4D4D4D;padding:var(--pad);height:76%;display:flex;flex-direction:column;gap:.45em;overflow:hidden}
.agt .at{font-weight:700;font-size:calc(1.5*var(--vw));line-height:1.25}
.agt .as{font-size:calc(1.2*var(--vw));line-height:1.35}
.agt .an{position:absolute;right:.3em;bottom:.05em;font-size:calc(4.4*var(--vw));line-height:1;color:#B3B3B3}
.agt.on{background:#BF1528;color:#fff;height:100%}
.agt.on .at{font-size:calc(2.3*var(--vw))}.agt.on .as{font-size:calc(1.45*var(--vw));color:#F5DCDF}
.agt.on ul.sq{margin-top:1.2em}.agt.on ul.sq li{color:#fff;font-size:calc(1.3*var(--vw))}.agt.on ul.sq li::before{background:#fff}
.agt.on .an{font-size:calc(9*var(--vw));color:#fff}
/* takeaway band (full width) */
.egband{flex:none;background:#BF1528;margin:0 calc(-1*var(--safe-r)) 0 calc(-1*var(--safe-l));padding:3.2vh var(--safe-l);text-align:center}
.egband p{color:#fff;font-size:calc(1.9*var(--vw));font-weight:700;line-height:1.25}
/* KPI tiles */
.egkpis{display:grid;grid-auto-flow:column;grid-auto-columns:minmax(0,1fr);gap:var(--gap-s);flex:none}
.egkpi{background:#BF1528;color:#fff;padding:min(1.2vw,2.1vh) min(1.4vw,2.5vh);display:flex;flex-direction:column;min-height:16vh}
.egkpi .kl{font-weight:700;font-size:calc(1.2*var(--vw))}
.egkpi .ke{font-size:calc(1*var(--vw));color:#F5DCDF;margin-top:.2em}
.egkpi .kv{margin-top:auto;padding-top:.3em;font-weight:700;font-size:calc(2.7*var(--vw));line-height:1;font-variant-numeric:tabular-nums}
/* pillars */
.egpillars{display:grid;grid-auto-flow:column;grid-auto-columns:minmax(0,1fr);gap:var(--gap);flex:none}
.egpillars.fill{flex:1;min-height:0;max-height:50vh}
.pil{background:#EFEDED;padding:calc(2*var(--vw)) var(--pad);display:flex;flex-direction:column;gap:.6em;border-top:.3vw solid #BF1528}
.pil h3{margin:0;font-size:calc(1.6*var(--vw));font-weight:700;line-height:1.25}
.pil p{font-size:calc(1.35*var(--vw));line-height:1.4;color:#262626}
.mi{display:block;width:calc(3*var(--vw));height:calc(3*var(--vw));color:#BF1528;margin-bottom:.4em}
.mi svg{width:100%;height:100%}
.nd{display:flex;align-items:center;justify-content:center;width:calc(3*var(--vw));height:calc(3*var(--vw));border-radius:50%;background:#BF1528;color:#fff;font-weight:700;font-size:calc(1.4*var(--vw));margin-bottom:.4em}
/* bar chart */
.egbars{margin:0;flex:1;min-height:0;display:flex;flex-direction:column;gap:.5em}
.ct{font-weight:700;font-size:calc(1.4*var(--vw));color:#262626}.ct span{font-weight:400}
.pa{position:relative;flex:1;min-height:calc(12*var(--vw))}
.pa .gl{position:absolute;left:0;right:0;height:1px;background:#E6E2E2}
.pa .gl:first-child{background:#8C8C8C}
.cols{position:absolute;inset:0;display:flex;z-index:1}
.bc{position:relative;flex:1}
.bar{position:absolute;left:max(18%,calc(50% - 3.6vw));right:max(18%,calc(50% - 3.6vw));bottom:0;display:block}
.bv{position:absolute;left:0;right:0;text-align:center;padding-bottom:.35em;font-size:calc(1.3*var(--vw));font-weight:700;color:#262626;font-variant-numeric:tabular-nums}
.bv.acc{color:#7A0E1C}
.bls{display:flex;flex:none}.bls span{flex:1;text-align:center;font-size:calc(1.1*var(--vw));color:#4D4D4D}
.brk{position:absolute;height:0;border-top:.12vw solid #262626;z-index:2}
.leg{position:absolute;width:0;border-left:.12vw solid #262626;transform:translateX(-50%);z-index:2}
.leg::after{content:"";position:absolute;left:-.4vw;bottom:-.1vw;border-left:.35vw solid transparent;border-right:.35vw solid transparent;border-top:.55vw solid #262626}
.pill{position:absolute;transform:translate(-50%,50%);background:#BF1528;color:#fff;font-weight:700;font-size:calc(1.15*var(--vw));padding:.3em 1em;border-radius:99px;white-space:nowrap;z-index:3}
.thr{position:absolute;left:0;right:0;height:0;border-top:.14vw dotted #7A0E1C;z-index:2}
.thl{position:absolute;transform:translateY(-.3em);font-size:calc(1.05*var(--vw));font-weight:700;color:#7A0E1C;z-index:2}
/* horizontal bars */
.eghbars{display:flex;flex-direction:column;gap:1.4vh;flex:none}
.eghbars .hr{display:grid;grid-template-columns:minmax(0,28%) 1fr;align-items:center;gap:1em;font-size:calc(1.3*var(--vw))}
.eghbars .ht{display:flex;align-items:center;gap:.6em}.eghbars .ht i{display:block;height:2.6vh}
.eghbars .ht b{font-variant-numeric:tabular-nums}
/* donut */
.egdonut{margin:auto;display:flex;align-items:center;justify-content:center;gap:calc(4*var(--vw))}
.dw{position:relative;width:calc(21*var(--vw));aspect-ratio:1;flex:none}
.dw svg{width:100%;height:100%;transform:rotate(-90deg)}
.dseg{fill:none;stroke-width:22;stroke-dasharray:var(--d) 100;stroke-dashoffset:var(--o)}
.dc{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center}
.dc b{font-size:calc(3*var(--vw));color:#BF1528;line-height:1.05}.dc span{font-size:calc(1*var(--vw));color:#4D4D4D}
.dlg{list-style:none;margin:0;padding:0;display:grid;gap:1.8vh;font-size:calc(1.5*var(--vw));min-width:24vw}
.dlg li{display:grid;grid-template-columns:auto 1fr auto;gap:.7em;align-items:center}
.dlg i{display:block;width:.85em;height:.85em}
/* KPI rings */
.egrings{display:flex;gap:calc(2*var(--vw));align-items:flex-end;justify-content:space-around;flex:none}
lv-ring{--tint:#EFEDED;--bar:#BF1528;--dark:#262626;--mut:#4D4D4D;font-size:calc(1.15*var(--vw))}
lv-ring.hero{--bar:#7A0E1C}
/* timeline: centred in the free height, labels above, text below */
.egtlwrap{flex:1;min-height:0;display:flex;align-items:center}
.egtl{list-style:none;margin:0;padding:0;width:100%;display:grid;grid-auto-flow:column;grid-auto-columns:minmax(0,1fr);gap:var(--gap-s);position:relative}
.egtl .line{position:absolute;left:0;right:0;top:calc(3*var(--vw) + 1.2vh + .8*var(--vw) - .1vw);height:.2vw;background:#BF1528}
.egtl li{position:relative;display:flex;flex-direction:column;align-items:center;text-align:center;gap:1.2vh;font-size:calc(1.5*var(--vw));line-height:1.35}
.egtl li b{color:#BF1528;font-size:calc(1.9*var(--vw));height:calc(3*var(--vw));display:flex;align-items:flex-end}
.egtl .dot{display:block;flex:none;width:calc(1.6*var(--vw));height:calc(1.6*var(--vw));border-radius:50%;background:#fff;border:.22vw solid #BF1528;position:relative;z-index:1}
.egtl li.now .dot{background:#BF1528}
.egtl li span{max-width:90%;color:#262626}
/* calm corporate motion: fade/rise, bars grow, brackets and rails draw, values count; logo fades only */
.lv-play .lv-in{animation:egIn .9s cubic-bezier(.25,.7,.25,1) backwards;animation-delay:calc(var(--i,0) * 110ms + 150ms)}
@keyframes egIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
.lv-play .eghead{animation:egFade .8s ease backwards .05s}
.lv-play .egside{animation:egSlide 1s cubic-bezier(.25,.7,.25,1) backwards .35s}
@keyframes egSlide{from{opacity:0;transform:translateX(3vw)}to{opacity:1;transform:none}}
.lv-play .bar.lv-grow{transform-origin:bottom center;animation:egGrow 1s cubic-bezier(.25,.7,.25,1) backwards;animation-delay:calc(var(--i,0) * 110ms + 450ms)}
@keyframes egGrow{from{transform:scaleY(0)}to{transform:none}}
.lv-play .bv{animation:egFade .5s ease backwards;animation-delay:1.3s}
.lv-play .brk.lv-draw{animation:lvDraw .9s cubic-bezier(.3,.6,.2,1) backwards 1.6s}
.lv-play .leg{animation:egFade .4s ease backwards 1.6s}
.lv-play .pill{animation:egFade .5s ease backwards 2.3s}
.lv-play .thr.lv-draw{animation:lvDraw .9s ease backwards 1.4s}.lv-play .thl{animation:egFade .5s ease backwards 2s}
.lv-play .dseg{animation:egSeg .9s cubic-bezier(.25,.7,.25,1) backwards;animation-delay:calc(var(--i,0) * 180ms + 400ms)}
@keyframes egSeg{from{stroke-dasharray:0 100}}
.lv-play .egtl .line.lv-draw{animation:lvDraw 1.6s cubic-bezier(.3,.6,.2,1) backwards .4s}
.lv-play .egtl li.lv-pop{animation:egIn .7s ease backwards;animation-delay:calc(var(--i,0) * 160ms + 600ms)}
.lv-play .agt.on{animation:egIn 1s cubic-bezier(.25,.7,.25,1) backwards .2s}
.lv-play .egband{animation:egFade 1s ease backwards .9s}
.lv-play .lv-logo,.lv-play .clogo,.lv-play .dlogo{animation:egFade 1s ease backwards .6s}
@keyframes egFade{from{opacity:0}to{opacity:1}}
'''

JS = r'''
document.querySelector(".lv-root").dataset.motionMs = "5200";
'''
