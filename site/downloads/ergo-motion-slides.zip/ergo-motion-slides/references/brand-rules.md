# ERGO brand rules for live slides (binding)

Layout: investor-deck style. Brand: ERGO. Same look as the `ergo-deck` skill, so static and live slides mix.

## Logo
- Only `ergo_motion.logo("red")` (white, light grey) or `logo("white")` (on red). Path data in assets/logo.json.
- Top-right on content slides (header), bottom-right on cover, divider and closer. Never on the left.
- No recolour, crop, rotate, stretch, outline, shadow or glow. Motion: fade only.

## Colour
- Logo Red #BF1528: titles, tiles, bands, primary bars, active agenda tile. Dark Red #7A0E1C (stand-in):
  thresholds, annotations, hero ring. Warm Grey #615E5C sparingly. Ink #262626, footer #4D4D4D, panel #EFEDED.
- Tints #DF8A93 #EBB9BE for comparison/prior period. No blue, teal or petrol.

## Type and frame
- Arial only (picture fallback uses Liberation Sans, metric-identical). Title top-left, regular, red.
- Footer in flow: source left, "Event - Title" + bold page number right. Square red bullets.

## Motion
- Calm: fade/rise, bars grow, values count up, brackets and rails draw, rings fill. One slow ambient drift on
  the cover. No 3D, tilt, blur or bounce.

## Content
- Plain, short text; the presenter talks. Real numbers need a source; otherwise "Illustrative".
- No commitments on anyone's behalf. Layout is not ERGO's official master; Dark Red is a stand-in.
